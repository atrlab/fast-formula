import * as vscode from "vscode";

export function devexStyle(context: vscode.ExtensionContext){
    const inputStyle = vscode.window.createTextEditorDecorationType({
        fontStyle: 'italic',
        overviewRulerColor: 'blue',
        overviewRulerLane: vscode.OverviewRulerLane.Right,
    });
    const localvariableStyle = vscode.window.createTextEditorDecorationType({
        fontWeight : 'bold',
        fontStyle: 'underline',
        color : 'gray',
        overviewRulerColor: 'gray',
        overviewRulerLane: vscode.OverviewRulerLane.Left,
    });
    const initializerStyle = vscode.window.createTextEditorDecorationType({
        cursor : 'help',
        fontWeight : 'bold',
        overviewRulerColor: 'green',
        backgroundColor: 'lightgray',
        overviewRulerLane: vscode.OverviewRulerLane.Center,
    });
    
    let activeEditor = vscode.window.activeTextEditor;

    if (activeEditor) {
		updateDecorations();
	}

    vscode.window.onDidChangeActiveTextEditor(editor => {
		activeEditor = editor;
		if (editor) {
			updateDecorations();
		}
	}, null, context.subscriptions);

	vscode.workspace.onDidChangeTextDocument(event => {
		if (activeEditor && event.document === activeEditor.document) {
			updateDecorations();
		}
	}, null, context.subscriptions);

    
    function updateDecorations() {
		if (!activeEditor) {
			return;
		}
		const regEx = /\b(iv|l)\w+/ig;
		
		const text = activeEditor.document.getText();

		const inputCollector: vscode.DecorationOptions[] = [];
		const localVariableCollector: vscode.DecorationOptions[] = [];

		let match;
		while (match = regEx.exec(text)) {
			const startPos = activeEditor.document.positionAt(match.index);
			const endPos = activeEditor.document.positionAt(match.index + match[0].length);
			
			if (match[0].startsWith('iv')) {
				const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: ['__Input__','Input variable `'+match[0]+'`.']};
				inputCollector.push(decoration);
			} else if(match[0].startsWith('l_')) {
				const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: ['__Variable__','Local variable `'+match[0]+'`.']};
				localVariableCollector.push(decoration);
			}
		}

		let match2;
		const regEx2 = /\b(EMPTY_TEXT_NUMBER|EMPTY_NUMBER_NUMBER|EMPTY_TEXT_TEXT|EMPTY_TEXT_NUMBER|EMPTY_DATE_NUMBER|EMPTY_DATE_TEXT)\b/ig;
		const text2 = activeEditor.document.getText();
		const initializerCollector: vscode.DecorationOptions[] = [];
		while (match2 = regEx2.exec(text2)) {
			const startPos = activeEditor.document.positionAt(match2.index);
			const endPos = activeEditor.document.positionAt(match2.index + match2[0].length);
			const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: ['__Initializer__','Builtin Initializers to initialize array `'+match2[0]+'`.']};
			initializerCollector.push(decoration);
		}
		activeEditor.setDecorations(inputStyle, inputCollector);
		activeEditor.setDecorations(localvariableStyle, localVariableCollector);
		activeEditor.setDecorations(initializerStyle, initializerCollector);
	}
}
