import * as vscode from "vscode";
import { stateManager } from "./state.service";

/**
 * Set storeData into context.globalState.
 * @param context :vscode.ExtensionContext
 * @param storeData : any
 */
export function setStoreData(context: vscode.ExtensionContext, storeData: any) {
  const state = stateManager(context);

  if (storeData !== undefined) {
    state.write({
      storeData: storeData
    });
  }
}



/**
 * Gets storeData from context.globalState.
 * @param context :vscode.ExtensionContext
 * @returns string
 */
export function getStoreData(context: vscode.ExtensionContext): any {
  const state = stateManager(context);

  const { storeData } = state.read();
  return storeData as any;
}


