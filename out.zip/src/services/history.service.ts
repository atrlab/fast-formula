import * as vscode from "vscode";
import { stateManager } from "./state.service";

export function setHistoryData(context: vscode.ExtensionContext, historyData: any) {
    const state = stateManager(context);

    if (historyData !== undefined) {
        state.writeHistory({
            historyData: historyData
        });
    }
}
export function getHistoryData(context: vscode.ExtensionContext): any {
    const state = stateManager(context);

    const { historyData } = state.readHistory();
    return historyData as any;
}
