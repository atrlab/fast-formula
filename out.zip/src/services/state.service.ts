import * as vscode from "vscode";
/**
* State Manager has read and write methods for api key. This methods set and get the api key from context.globalState.
* @param context :vscode.ExtensionContext.
* @returns void.
*/

export function stateManager(context: vscode.ExtensionContext) {
    return {
      read,
      write,
      writeHistory,
      readHistory
    };
  
    function read() {
      return {
        storeData: context.globalState.get('storeData')
      };
    }
    
    function readHistory() {
      return {
        historyData: context.globalState.get('historyData')
      };
    }
  
    function write(newState: any) {
      context.globalState.update('storeData', newState.storeData);
    }
  
    function writeHistory(newState: any) {
      context.globalState.update('historyData', newState.historyData);
    }
  }