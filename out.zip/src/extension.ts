
import * as vscode from 'vscode';
import { Data } from './data';

import { DevexFFGPTPanel } from './panels/main-view-panel';
import { ImagePanel } from './panels/image-view-panel';
import { SideBarViewProvider } from './panels/side-bar-view-panel';

import { devexKeywords } from './api/devex-keyword.api';
import { devexDataTypes } from './api/devex-datatype.api';
import { devexContexts } from './api/devex-context.api';
import { devexInitializers } from './api/devex-initializer.api';

import { devexRefactorCode } from './commands/refactor-code.cmd';
import { devexAddComment } from './commands/add-comment.cmd';
import { devexAddDocument } from './commands/add-document.cmd';
import { devexDotFunctions, devexBaseFunctions } from './api/devex-functions.api';

import { devexStyle } from './services/style.service';

import { devexGenerateFormulaSkeleton } from './commands/generate-formula.command';

class RunningNumber {
    static index = 1;

    static run() {
        return RunningNumber.index++;
    }
}

export async function activate(context: vscode.ExtensionContext) {

	console.log('DevEx Started');
	
	devexStyle(context);

	devexKeywords(context, (new Data()).getKewords());

	devexDataTypes(context, (new Data()).getDataTypes());

	
	devexInitializers(context, (new Data()).getInitializers());
	
	devexDotFunctions(context);
	devexBaseFunctions(context);

	devexRefactorCode();
	devexAddComment();
	devexAddDocument();

	devexGenerateFormulaSkeleton(context);


	// Chat panel register
	context.subscriptions.push(vscode.commands.registerCommand("devex-ff-gpt.start", () => {	
		DevexFFGPTPanel.render(context);
	}));

	// Image panel register
	context.subscriptions.push(vscode.commands.registerCommand("devex-ff-gpt.start-image", () => {	
		ImagePanel.render(context);
	}));

	// Side Bar View Provider
	context.subscriptions.push(vscode.window.registerWebviewViewProvider(SideBarViewProvider.viewType, new SideBarViewProvider(context.extensionUri, context)));


	context.subscriptions.push(vscode.window.onDidChangeActiveTextEditor(loadContexts));
	
	function loadContexts()
	{
		devexContexts(context, RunningNumber.run());
	}

	console.log('DevEx Finished');
}

export function deactivate() { 
}
