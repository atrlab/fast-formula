import * as vscode from 'vscode';
import { devexDavinci } from '../api/devex-davinci.api';

export function devexAddDocument() {
    vscode.commands.registerCommand("devex-ff-gpt.addDocumentaion", () => {
        const textEditor = vscode.window.activeTextEditor;
        if (!textEditor) {
            return; // No open text editor
        }
        var selection = textEditor.selection;
        var selectedText = textEditor.document.getText(selection);

        switch (textEditor.document.languageId) {
            case 'fastformula':
            {
                const prompt = "Generate documentation comment following FFDoc specification with input parameters and return value type and add comment closing tag for the following code. " + selectedText;
                devexDavinci(prompt).then(result => {
                    const parts = result.split('*/') as string[];
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "*/ \n" + selectedText));
                });
                break;
            }
            case 'javascript':
                {
                    const prompt = "Generate documentation comment following JSDoc specification with input parameters and return value type and add comment closing tag for the following code. " + selectedText;

                    devexDavinci(prompt).then(result => {
                        const parts = result.split('*/') as string[];
                        textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "*/ \n" + selectedText));
                    });
                    break;
                }
            case 'java':
                {
                    const prompt = "Generate documentation comment following Javadoc specification with input parameters and return value type and add comment closing tag for the following code. " + selectedText;

                    devexDavinci(prompt).then(result => {
                        const parts = result.split('*/') as string[];
                        textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "*/ \n" + selectedText));
                    });
                    break;
                }
            case 'typescript':
                {
                    const prompt = "Generate documentation comment following TSDoc specification with input parameters and return value type and add comment closing tag for the following code. " + selectedText;

                    devexDavinci(prompt).then(result => {
                        const parts = result.split('*/') as string[];
                        textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "*/ \n" + selectedText));
                    });
                    break;
                }
            case 'csharp':
                {
                    const prompt = "Generate documentation following Annex D Documentation comments specification with input parameters and return value type and add summary closing tag for the following c# code. " + selectedText;

                    devexDavinci(prompt).then(result => {
                        const parts = result.split('</returns>') as string[];
                        textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "</returns> \n" + selectedText));
                    });
                    break;
                }

            default:
                break;
        }

      
    });
}