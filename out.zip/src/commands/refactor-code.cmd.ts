import * as vscode from 'vscode';
import { devexDavinci } from '../api/devex-davinci.api';

export function devexRefactorCode() {
    vscode.commands.registerCommand("devex-ff-gpt.refactor", () => {
        const textEditor = vscode.window.activeTextEditor;
        if (!textEditor) {
            return; // No open text editor
        }
        var selection = textEditor.selection;
        var selectedText = textEditor.document.getText(selection);
        let prompt = `Refactor the following ${textEditor.document.languageId} code ` + selectedText;
    
        devexDavinci(prompt).then(result => {
            textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result));
        });
    });
}
