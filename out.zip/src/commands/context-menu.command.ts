
import * as vscode from 'vscode';
import { devexDavinci } from '../api/devex-davinci.api';
import { window, ProgressLocation } from 'vscode';

export function registerCommand() {


    /*Add Comment */
    vscode.commands.registerCommand("devex-ff-gpt.addComments", () => {
        addComment();
    });

    /*Add Documentaion */
    vscode.commands.registerCommand("devex-ff-gpt.addDocumentaion", () => {
        addDocument();
    });
}
/**
 * Refactor code via ChatGpt
 * @param apiKey :string
 * @returns 
 */
function refactorCode() {
    const textEditor = vscode.window.activeTextEditor;
    if (!textEditor) {
        return; // No open text editor
    }
    var selection = textEditor.selection;
    var selectedText = textEditor.document.getText(selection);
    let prompt = `Refactor the following ${textEditor.document.languageId} code ` + selectedText;

    devexDavinci(prompt).then(result => {
        // vscode.commands.executeCommand("cursorMove", { "to": "viewPortTop" });
        textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result));
    });
}

/**
 * Add comments code via ChatGpt
 * @param apiKey :string
 * @returns 
 */
function addComment() {
    const textEditor = vscode.window.activeTextEditor;
    if (!textEditor) {
        return; // No open text editor
    }
    var selection = textEditor.selection;
    var selectedText = textEditor.document.getText(selection);
    switch (textEditor.document.languageId) {
        case 'html':
            {
                let prompt = "Add comments for the following HTML code and format with 80 colums." + selectedText;
                prompt = prompt.replace(/"/g, "'");

                devexDavinci(prompt).then(result => {
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result + "\n" + selectedText));
                });
                break;
            }
        case 'css':
            {
                let prompt = "Add comments for the following CSS code and format with 80 colums." + selectedText;
                prompt = prompt.replace(/"/g, "'");

                devexDavinci(prompt).then(result => {
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result + "\n" + selectedText));
                });
                break;
            }
        default:
            const prompt = "Add comments for the following code and format with 80 colums." + selectedText;

            devexDavinci(prompt).then(result => {
                textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result + "\n" + selectedText));
            })
            break;
    }

}

/**
 * Add documents via ChatGpt
 * @param apiKey :string
 * @returns 
 */
function addDocument() {
    const textEditor = vscode.window.activeTextEditor;
    if (!textEditor) {
        return; // No open text editor
    }
    var selection = textEditor.selection;
    var selectedText = textEditor.document.getText(selection);

    switch (textEditor.document.languageId) {

        case 'javascript':
            {
                const prompt = "Generate documentation comment following JSDoc specification with input parameters and return value type and add comment closing tag for the following code. " + selectedText;

                devexDavinci(prompt).then(result => {
                    const parts = result.split('*/') as string[];
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "*/ \n" + selectedText));
                });
                break;
            }
        case 'java':
            {
                const prompt = "Generate documentation comment following Javadoc specification with input parameters and return value type and add comment closing tag for the following code. " + selectedText;

                devexDavinci(prompt).then(result => {
                    const parts = result.split('*/') as string[];
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "*/ \n" + selectedText));
                });
                break;
            }
        case 'typescript':
            {
                const prompt = "Generate documentation comment following TSDoc specification with input parameters and return value type and add comment closing tag for the following code. " + selectedText;

                devexDavinci(prompt).then(result => {
                    const parts = result.split('*/') as string[];
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "*/ \n" + selectedText));
                });
                break;
            }
        case 'csharp':
            {
                const prompt = "Generate documentation following Annex D Documentation comments specification with input parameters and return value type and add summary closing tag for the following c# code. " + selectedText;

                devexDavinci(prompt).then(result => {
                    const parts = result.split('</returns>') as string[];
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, parts[0] + "</returns> \n" + selectedText));
                });
                break;
            }

        default:
            break;
    }

    function showProgressRunning() {
        let customCancellationToken: vscode.CancellationTokenSource | null = null;

        window.withProgress({
            location: ProgressLocation.Notification,
            title: "I am long running!",
            cancellable: true
        }, (progress, token) => {

            customCancellationToken = new vscode.CancellationTokenSource();
            customCancellationToken.token.onCancellationRequested(() => {
                customCancellationToken?.dispose();
                customCancellationToken = null;

                vscode.window.showInformationMessage("Cancelled the progress");
                return;
            });


            token.onCancellationRequested(() => {
                customCancellationToken?.cancel()
                console.log("User canceled the long running operation");
            });

            progress.report({ increment: 0 });

            setTimeout(() => {
                progress.report({ increment: 10, message: "Running..." });
            }, 1000);

            setTimeout(() => {
                progress.report({ increment: 40, message: "Running..." });
            }, 2000);

            setTimeout(() => {
                progress.report({ increment: 50, message: "Running..." });
            }, 3000);

            const p = new Promise<void>(resolve => {
                setTimeout(() => {
                    resolve();
                }, 5000);
            });

            return p;
        });

    }
}
