import * as vscode from 'vscode';
import { devexDavinci } from '../api/devex-davinci.api';

export function devexAddComment() {
    vscode.commands.registerCommand("devex-ff-gpt.addComments", () => {
        const textEditor = vscode.window.activeTextEditor;
        if (!textEditor) {
            return; // No open text editor
        }
        var selection = textEditor.selection;
        var selectedText = textEditor.document.getText(selection);
        switch (textEditor.document.languageId) {

            case 'fastformula':
            {
                let prompt = "Add comments for the following Fast Formula code and format with 80 colums." + selectedText;
                prompt = prompt.replace(/"/g, "'");
                devexDavinci(prompt).then(result => {
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result + "\n" + selectedText));
                });
                break;
            }
            case 'html':
            {
                let prompt = "Add comments for the following HTML code and format with 80 colums." + selectedText;
                prompt = prompt.replace(/"/g, "'");
                devexDavinci(prompt).then(result => {
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result + "\n" + selectedText));
                });
                break;
            }
            case 'css':
            {
                let prompt = "Add comments for the following CSS code and format with 80 colums." + selectedText;
                prompt = prompt.replace(/"/g, "'");
                devexDavinci(prompt).then(result => {
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result + "\n" + selectedText));
                });
                break;
            }
            default:
                const prompt = "Add comments for the following code and format with 80 colums." + selectedText;
                devexDavinci(prompt).then(result => {
                    textEditor.edit(editBuilder => editBuilder.replace(textEditor.selection, result + "\n" + selectedText));
                });
                break;
        }
    });
}