export const DEFAULT_CHAT_URL           = 'https://api.openai.com/v1/chat/completions';
export const DEFAULT_CHAT_KEY           = 'https://api.openai.com/v1/chat/completions';
export const DEFAULT_CHAT_MODEL         = "gpt-3.5-turbo";
export const DAVINCI_CHAT_MODEL         = "text-davinci-003";
export const DEFAULT_CHAT_TEMPRATURE    = .7;

export const DEFAULT_IMAGINE_URL        = 'https://api.openai.com/v1/images/generations';

export const DEFAULT_DEVEX_LANGUAGE      = 'fastformula';
