import { fetch } from 'undici';
import { TextDecoderStream } from 'node:stream/web';
import { Observable } from 'rxjs';
import * as constants from '../constants';
/**
 * Create asnyc request to ChatGpt api and gets straem.
 * @param question is that want to ask to ChatGpt.
 * @param apikey of ChatGpt.
 * @param temperature.
 * @returns 
 */
export function devexStream(query: string | undefined,  temperature: number): Observable<string> {

    const apiUrl = constants.DEFAULT_CHAT_URL;
    const apiKey = constants.DEFAULT_CHAT_KEY;
    const apiModel = constants.DEFAULT_CHAT_MODEL;
    
    return new Observable<string>(observer => {
        // 👇️ const response: Response
        const response = fetch(apiUrl, {
            method: 'POST',
            body: JSON.stringify({
                model: apiModel,
                messages: [{ role: "user", content: query }],
                temperature: Number(temperature),
                stream: true
            }),
            headers: {
                'Content-Type': 'application/json',
                authorization: 'Bearer ' + apiKey,
            },
        });

        let content = '';
        response.then(async res => {
            const textStream = res.body?.pipeThrough(new TextDecoderStream());
            if (textStream) {
                for await (const chunk of textStream) {
                    const eventStr = chunk.split('\n\n');
                    for (let i = 0; i < eventStr.length; i++) {
                        const str = eventStr[i];
                        if (str === 'data: [DONE]') {
                            break;
                        }
                        if (str && str.slice(0, 6) === 'data: ') {
                            const jsonStr = str.slice(6);
                            const data: any = JSON.parse(jsonStr);
                            const thisContent = data.choices[0].delta?.content || '';
                            content += thisContent;
                            observer.next(thisContent);
                        }
                    }
                }
            }
        }).catch((err: Error) => {
            observer.error(err?.message);
        });
    });
}
