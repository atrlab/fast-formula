'use strict';
import * as vscode from 'vscode';
import { DEFAULT_DEVEX_LANGUAGE } from './../constants';


export function devexBaseFunctions(context: vscode.ExtensionContext) {
    context.subscriptions.push(
        vscode.languages.registerCompletionItemProvider(
            DEFAULT_DEVEX_LANGUAGE,
            {
                provideCompletionItems(document: vscode.TextDocument, position: vscode.Position) {

                    const getContext = new vscode.CompletionItem('get_context', vscode.CompletionItemKind.Method);
                    getContext.insertText = new vscode.SnippetString(" get_context(${1|PERSON_ID,EFFECTIVE_DATE|}, ${2|0,'1901/01/01'(date),'NULL'|})");
                    getContext.documentation = new vscode.MarkdownString('[# get_context *** hello world]');

                    const abs = new vscode.CompletionItem('abs', vscode.CompletionItemKind.Function);
                    abs.insertText = new vscode.SnippetString(' abs(${1:Number})');
                    abs.documentation = new vscode.MarkdownString('Returns the absolute value of a number | Return Data Type : Number');

                    const addDays = new vscode.CompletionItem('add_days', vscode.CompletionItemKind.Function);
                    addDays.insertText = new vscode.SnippetString(' add_days(${1:Date}, ${2:Number of Days})');
                    addDays.documentation = new vscode.MarkdownString('Returns the result of adding a number of whole days to a date | Return Data Type : Date');

                    const addlog = new vscode.CompletionItem('add_log', vscode.CompletionItemKind.Function);
                    addlog.insertText = new vscode.SnippetString(' add_log(${1:Ffs Id}, ${2:Text})');
                    addlog.documentation = new vscode.MarkdownString('Adds Log information to table | Return Data Type : Number');

                    const addMonths = new vscode.CompletionItem('add_months', vscode.CompletionItemKind.Function);
                    addMonths.insertText = new vscode.SnippetString(' add_months(${1:Date}, ${2:Number of Months})');
                    addMonths.documentation = new vscode.MarkdownString('Returns the result of adding a number of months to a date | Return Data Type : Date');

                    const addRlog = new vscode.CompletionItem('add_rlog', vscode.CompletionItemKind.Function);
                    addRlog.insertText = new vscode.SnippetString(' add_rlog(${1:Ffs Id}, ${2:Rule Id}, ${3:Text})');
                    addRlog.documentation = new vscode.MarkdownString('Adds Log information to log table | Return Data Type : Number');

                    const addYears = new vscode.CompletionItem('add_years', vscode.CompletionItemKind.Function);
                    addYears.insertText = new vscode.SnippetString(' add_years(${1:Date}, ${2:Number of Years})');
                    addYears.documentation = new vscode.MarkdownString('Returns the result of adding a number of whole years to a date | Return Data Type : Date');

                    const archiveClear = new vscode.CompletionItem('archive_clear', vscode.CompletionItemKind.Function);
                    archiveClear.insertText = new vscode.SnippetString(' archive_clear()');
                    archiveClear.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_archive_clear_record = new vscode.CompletionItem('archive_clear_record', vscode.CompletionItemKind.Function);
                    l_archive_clear_record.insertText = new vscode.SnippetString(' archive_clear_record()');
                    l_archive_clear_record.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_archive_flush = new vscode.CompletionItem('archive_flush', vscode.CompletionItemKind.Function);
                    l_archive_flush.insertText = new vscode.SnippetString(' archive_flush()');
                    l_archive_flush.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_archive_init = new vscode.CompletionItem('archive_init', vscode.CompletionItemKind.Function);
                    l_archive_init.insertText = new vscode.SnippetString(' archive_init(${1:Category})');
                    l_archive_init.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_archive_message = new vscode.CompletionItem('archive_message', vscode.CompletionItemKind.Function);
                    l_archive_message.insertText = new vscode.SnippetString(' archive_message(${1:Application}, ${2:Message}, ${3:Severity}, ${4:Token Name1[...]}, ${5:Token Value1[...]}, ${6:Token Name2[...]}, ${7:Token Value2[...]}, ${8:Token Name3[...]}, ${9:Token Value3[...]}, ${10:Token Name4[...]},${11:Token Value4[...]}, ${12:Token Name5[...]}, ${13:Token Value5[...]})');
                    l_archive_message.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_archive_value = new vscode.CompletionItem('archive_value', vscode.CompletionItemKind.Function);
                    l_archive_value.insertText = new vscode.SnippetString(' archive_value(${1:Name}, ${2:Value})');
                    l_archive_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_ben_chk_abs_type = new vscode.CompletionItem('ben_chk_abs_type', vscode.CompletionItemKind.Function);
                    l_ben_chk_abs_type.insertText = new vscode.SnippetString(' ben_chk_abs_type(${1:Absence Type Id}, ${2:Yes/No})');
                    l_ben_chk_abs_type.documentation = new vscode.MarkdownString('Called from absences plan eligibility other rule formula | Return Data Type : Text');

                    const l_ben_fn_aca_reporting = new vscode.CompletionItem('ben_fn_aca_reporting', vscode.CompletionItemKind.Function);
                    l_ben_fn_aca_reporting.insertText = new vscode.SnippetString(' ben_fn_aca_reporting(${1:Mode})');
                    l_ben_fn_aca_reporting.documentation = new vscode.MarkdownString('BEN ACA reporting function | Return Data Type : Text');

                    const l_ben_fn_effective_date = new vscode.CompletionItem('ben_fn_effective_date', vscode.CompletionItemKind.Function);
                    l_ben_fn_effective_date.insertText = new vscode.SnippetString(' ben _fn_effective_date()');
                    l_ben_fn_effective_date.documentation = new vscode.MarkdownString('BEN Formula Functions for BW | Return Data Type : date');

                    const l_ben_fn_get_char_value = new vscode.CompletionItem('ben_fn_get_char_value', vscode.CompletionItemKind.Function);
                    l_ben_fn_get_char_value.insertText = new vscode.SnippetString(' ben fn get char value(${1:Table Name}, ${2:Column Name}, ${3:Plan Name[...]}, ${4:Option Name[...]}, ${5:Add Key NAME[...]}, ${6:Add Key Value[...]})');
                    l_ben_fn_get_char_value.documentation = new vscode.MarkdownString('BEN Formula Functions for BW | Return Data Type : Text');

                    const l_calculate_hours_worked = new vscode.CompletionItem('calculate_hours_worked', vscode.CompletionItemKind.Function);
                    l_calculate_hours_worked.insertText = new vscode.SnippetString(' calculate_hours_worked(${1:Standard Hours}, ${2:Range Start}, ${3:Range End}, ${4:Standard Frequency})');
                    l_calculate_hours_worked.documentation = new vscode.MarkdownString('This function determines the no of hours worked | Return Data Type : Number');

                    const l_calculate_payroll_periods = new vscode.CompletionItem('calculate_payroll_periods', vscode.CompletionItemKind.Function);
                    l_calculate_payroll_periods.insertText = new vscode.SnippetString(' calculate_payroll_periods()');
                    l_calculate_payroll_periods.documentation = new vscode.MarkdownString('This function calculates the payroll periods | Return Data Type : Number');

                    const l_calc_dir_exists = new vscode.CompletionItem('calc_dir_exists', vscode.CompletionItemKind.Function);
                    l_calc_dir_exists.insertText = new vscode.SnippetString(' calc_dir_exists()');
                    l_calc_dir_exists.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_calc_dir_get_override_level = new vscode.CompletionItem('calc_dir_get_override_level', vscode.CompletionItemKind.Function);
                    l_calc_dir_get_override_level.insertText = new vscode.SnippetString(' calc_dir_get_override_level(${1:Override Type})');
                    l_calc_dir_get_override_level.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_calc_dir_text_value = new vscode.CompletionItem('calc_dir_text_value', vscode.CompletionItemKind.Function);
                    l_calc_dir_text_value.insertText = new vscode.SnippetString(' calc_dir_text_value(${1:Range Value[...]})');
                    l_calc_dir_text_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_calc_dir_value = new vscode.CompletionItem('calc_dir_value', vscode.CompletionItemKind.Function);
                    l_calc_dir_value.insertText = new vscode.SnippetString(' calc_dir_value(${1:Periodicity}, ${2:Out Uom}, ${3:Base Value}, ${4:Range Value[...]}, ${5:Factor[...]}, ${5:Range Offset[...]}, ${5:Range Name[...]})');
                    l_calc_dir_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_calc_dir_value_detail = new vscode.CompletionItem('calc_dir_value_detail', vscode.CompletionItemKind.Function);
                    l_calc_dir_value_detail.insertText = new vscode.SnippetString(' calc_dir_value_detail(${1:Item Calc Type}, ${2:Overall Calc Type}, ${3:Low Value}, ${4:High Value}, ${5:Base Value}, ${6:Rate}, ${7:Flat Amount}, ${8:Multiplier}, ${9:Parameter}, ${10:A}, ${11:B}, ${12:C}, ${13:Val Def Name}, ${14:Override Flags})');
                    l_calc_dir_value_detail.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_ca_formula_logging = new vscode.CompletionItem('ca_formula_logging', vscode.CompletionItemKind.Function);
                    l_ca_formula_logging.insertText = new vscode.SnippetString(' ca_formula_logging(${1:Print Message Code}, ${2:Print Message})');
                    l_ca_formula_logging.documentation = new vscode.MarkdownString('Function to put debug message in extract fast formula | Return Data Type : Text');

                    const l_chr = new vscode.CompletionItem('chr', vscode.CompletionItemKind.Function);
                    l_chr.insertText = new vscode.SnippetString(' chr(${1:Number})');
                    l_chr.documentation = new vscode.MarkdownString('Returns a string containing a single character corresponding to a number code | Return Data Type : Text');

                    const l_clear_globals = new vscode.CompletionItem('clear_globals', vscode.CompletionItemKind.Function);
                    l_clear_globals.insertText = new vscode.SnippetString(' clear_globals()');
                    l_clear_globals.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_convert = new vscode.CompletionItem('convert', vscode.CompletionItemKind.Function);
                    l_convert.insertText = new vscode.SnippetString(' convert(${1:Expression}, ${2:Destination Char Set}, ${3:Source Char Set[...]})');
                    l_convert.documentation = new vscode.MarkdownString('Returns the result of converting a string in one character set to a string in another character set | Return Data Type : Text');

                    const l_date_to_text = new vscode.CompletionItem('date_to_text', vscode.CompletionItemKind.Function);
                    l_date_to_text.insertText = new vscode.SnippetString(' date_to_text(${1:Date})');
                    l_date_to_text.documentation = new vscode.MarkdownString('Returns the result of converting a date to a string in YYYY/DD/MM HH24:MM:SS format | Return Data Type : Text');

                    const l_days_between = new vscode.CompletionItem('days_between', vscode.CompletionItemKind.Function);
                    l_days_between.insertText = new vscode.SnippetString(' days_between(${1:Date1}, ${2:Date2})');
                    l_days_between.documentation = new vscode.MarkdownString('Returns the number of days between two dates| Return Data Type : Number');

                    const l_debug = new vscode.CompletionItem('debug', vscode.CompletionItemKind.Function);
                    l_debug.insertText = new vscode.SnippetString(' debug(${1:Message})');
                    l_debug.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_define_range = new vscode.CompletionItem('define_range', vscode.CompletionItemKind.Function);
                    l_define_range.insertText = new vscode.SnippetString(' define_range_item(${1:Range Name}, ${2:Low Value}, ${3:High Value})');
                    l_define_range.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_define_range_item = new vscode.CompletionItem('define_range_item', vscode.CompletionItemKind.Function);
                    l_define_range_item.insertText = new vscode.SnippetString(' define_range_item(${1:Range Name}, ${2:Low Value}, ${3:High Value})');
                    l_define_range_item.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_element_rate_converter = new vscode.CompletionItem('element_rate_converter', vscode.CompletionItemKind.Function);
                    l_element_rate_converter.insertText = new vscode.SnippetString(' element_rate_converter(${1:Source Amount}, ${2:Source Periodicity}, ${3:Target Periodicity}, ${4:Date Used})');
                    l_element_rate_converter.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_ess_log_write = new vscode.CompletionItem('ess_log_write', vscode.CompletionItemKind.Function);
                    l_ess_log_write.insertText = new vscode.SnippetString(' ess_log_write(${1:Log Message})');
                    l_ess_log_write.documentation = new vscode.MarkdownString('Write a message to the Scheduled Process logging system from a formula | Return Data Type : Text');

                    const l_floor = new vscode.CompletionItem('floor', vscode.CompletionItemKind.Function);
                    l_floor.insertText = new vscode.SnippetString(' floor(${1:Number})');
                    l_floor.documentation = new vscode.MarkdownString('Returns the largest integer value less than or equal to a number | Return Data Type : Number');

                    const l_get_absence = new vscode.CompletionItem('get_absence', vscode.CompletionItemKind.Function);
                    l_get_absence.insertText = new vscode.SnippetString(' get_absence(${1:Start Date}, ${2:Calculation Date})');
                    l_get_absence.documentation = new vscode.MarkdownString('This function returns the Absence duration | Return Data Type : Number');

                    const l_get_absence_counts = new vscode.CompletionItem('get_absence_counts', vscode.CompletionItemKind.Function);
                    l_get_absence_counts.insertText = new vscode.SnippetString(' get_absence_counts(${1:Person Id}, ${2:Include Type Id}, ${3:Exclude Type Id}, ${4:Include Categor Id}, ${5:Exclude Category Id}, ${6:Include Reason Id}, ${7:Exclude Reason Id}, ${8:Start Date From}, ${9:Start Date To}, ${10:Duration Days}, ${11:Duration Hours}, ${12:Duration Cal}, ${13:Duration Weeks}, ${14:Duration Months}, ${15:Duration Years}, ${16:Occurances})');
                    l_get_absence_counts.documentation = new vscode.MarkdownString('This formula function returns Absence count details | Return Data Type : Number');

                    const l_get_absence_days_per_type = new vscode.CompletionItem('get_absence_days_per_type', vscode.CompletionItemKind.Function);
                    l_get_absence_days_per_type.insertText = new vscode.SnippetString(' get_absence_days_per_type(${1:Absence Type Name}, ${2:Start Date}, ${3:End Date})');
                    l_get_absence_days_per_type.documentation = new vscode.MarkdownString('This function returns duration of absences taken during the given period for the given type Return value is days | Return Data Type : Number');

                    const l_get_abs_min_max_dates = new vscode.CompletionItem('get_abs_min_max_dates', vscode.CompletionItemKind.Function);
                    l_get_abs_min_max_dates.insertText = new vscode.SnippetString(' get_abs_min_max_dates(${1:Person Id}, ${2:Include Type Id}, ${3:Exclude Type Id}, ${4:Include Categor Id}, ${5:Exclude Category Id}, ${6:Include Reason Id}, ${7:Exclude Reason Id}, ${8:Start Date From}, ${9:Start Date To}, ${10:Min Date}, ${11:Max Date})');
                    l_get_abs_min_max_dates.documentation = new vscode.MarkdownString('This formula function returns minimum and maximum Absence dates | Return Data Type : Number');

                    const l_get_accrual_balance = new vscode.CompletionItem('get_accrual_balance', vscode.CompletionItemKind.Function);
                    l_get_accrual_balance.insertText = new vscode.SnippetString(' get_accrual_balance()');
                    l_get_accrual_balance.documentation = new vscode.MarkdownString('This formula function gives duration between two dates | Return Data Type : Number');

                    const l_get_accrual_band = new vscode.CompletionItem('get_accrual_band', vscode.CompletionItemKind.Function);
                    l_get_accrual_band.insertText = new vscode.SnippetString(' get_accrual_band(${1:Band Group}, ${2:Band Range})');
                    l_get_accrual_band.documentation = new vscode.MarkdownString('This function retrieves the Band details | Return Data Type : Number');

                    const l_get_asg_inactive_days = new vscode.CompletionItem('get_asg_inactive_days', vscode.CompletionItemKind.Function);
                    l_get_asg_inactive_days.insertText = new vscode.SnippetString(' get_asg_inactive_days(${1:Period Start Date}, ${2:Period End Date})');
                    l_get_asg_inactive_days.documentation = new vscode.MarkdownString('This function gives Assignment inactive days | Return Data Type : Number');

                    const l_get_asg_status = new vscode.CompletionItem('get_asg_status', vscode.CompletionItemKind.Function);
                    l_get_asg_status.insertText = new vscode.SnippetString(' get_asg_status(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_asg_status.documentation = new vscode.MarkdownString('Get Assignment status | Return Data Type : Number');

                    const l_get_assignment_salary = new vscode.CompletionItem('get_assignment_salary', vscode.CompletionItemKind.Function);
                    l_get_assignment_salary.insertText = new vscode.SnippetString(' get_assignment_salary()');
                    l_get_assignment_salary.documentation = new vscode.MarkdownString('Function to get the Assignment\'s salary and currency code | Return Data Type : Number');

                    const l_get_assignment_status = new vscode.CompletionItem('get_assignment_status', vscode.CompletionItemKind.Function);
                    l_get_assignment_status.insertText = new vscode.SnippetString(' get_assignment_status()');
                    l_get_assignment_status.documentation = new vscode.MarkdownString('Function to determine the Assignment status | Return Data Type : Number');

                    const l_get_bal_comp_val = new vscode.CompletionItem('get_bal_comp_val', vscode.CompletionItemKind.Function);
                    l_get_bal_comp_val.insertText = new vscode.SnippetString(' get_bal_comp_val(${1:Plan Name[...]}, ${2:Start Date[...]}, ${3:End Date[...]}, ${4:Type[...]}, ${5:Adj Reason[...]})');
                    l_get_bal_comp_val.documentation = new vscode.MarkdownString('This formula function returns component values of a balance | Return Data Type : Number');

                    const l_get_bal_hdr_val = new vscode.CompletionItem('get_bal_hdr_val', vscode.CompletionItemKind.Function);
                    l_get_bal_hdr_val.insertText = new vscode.SnippetString(' get_bal_hdr_val(${1:Plan Name}, ${2:Begin Balance}, ${3:Accrued}, ${4:Used}, ${5:End Balance}, ${6:Accrual Period})');
                    l_get_bal_hdr_val.documentation = new vscode.MarkdownString('This formula function returns details of accrual balance header record | Return Data Type : Number');

                    const l_get_calculated_hours = new vscode.CompletionItem('get_calculated_hours', vscode.CompletionItemKind.Function);
                    l_get_calculated_hours.insertText = new vscode.SnippetString(' get_calculated_hours(${1:Person Assignment ID}, ${2:Person ID}, ${3:Start Date}, ${4:Stop Date}, ${5:Payroll Time Type[...]}, ${6:Pyr Aprv Status[...]}, ${7:Default Value[...]})');
                    l_get_calculated_hours.documentation = new vscode.MarkdownString('This function gets Time and Labor calculated hours | Return Data Type : Number');

                    const l_get_carry_over = new vscode.CompletionItem('get_carry_over', vscode.CompletionItemKind.Function);
                    l_get_carry_over.insertText = new vscode.SnippetString(' get_carry_over(${1:Start Date}, ${2:Calculation Date})');
                    l_get_carry_over.documentation = new vscode.MarkdownString('This function returns the Carryover amount | Return Data Type : Number');

                    const l_get_context_value = new vscode.CompletionItem('get_context_value', vscode.CompletionItemKind.Function);
                    l_get_context_value.insertText = new vscode.SnippetString(' get_context_value(${1:Name})');
                    l_get_context_value.documentation = new vscode.MarkdownString('This function gives the value for the context | Return Data Type : Text');

                    const l_get_context_value_date = new vscode.CompletionItem('get_context_value_date', vscode.CompletionItemKind.Function);
                    l_get_context_value_date.insertText = new vscode.SnippetString(' get_context_value_date(${1:Name})');
                    l_get_context_value_date.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Date');

                    const l_get_context_value_number = new vscode.CompletionItem('get_context_value_number', vscode.CompletionItemKind.Function);
                    l_get_context_value_number.insertText = new vscode.SnippetString('  get_context_value_number(${1:Name})');
                    l_get_context_value_number.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_get_date = new vscode.CompletionItem('get_date', vscode.CompletionItemKind.Function);
                    l_get_date.insertText = new vscode.SnippetString(' get_date(${1:Name})');
                    l_get_date.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Date');

                    const l_get_date_day_of_week = new vscode.CompletionItem('get_date_day_of_week', vscode.CompletionItemKind.Function);
                    l_get_date_day_of_week.insertText = new vscode.SnippetString(' get_date_day_of_week(${1:Date})');
                    l_get_date_day_of_week.documentation = new vscode.MarkdownString('Get short Day of Week from date | Return Data Type : Text');

                    const l_get_duration = new vscode.CompletionItem('get_duration', vscode.CompletionItemKind.Function);
                    l_get_duration.insertText = new vscode.SnippetString(' abs(${1:Number})');
                    l_get_duration.documentation = new vscode.MarkdownString('This formula function gives duration between two dates | Return Data Type : Number');

                    const l_get_earliest_asgchange_date = new vscode.CompletionItem('get_earliest_asgchange_date', vscode.CompletionItemKind.Function);
                    l_get_earliest_asgchange_date.insertText = new vscode.SnippetString(' get_earliest_asgchange_date(${1:Legislative Data Group ID}, ${2:Pay Assignment ID}, ${3:Event Group}, ${4:Start Date}, ${5:End Date}, ${6:Recalculation Date})');
                    l_get_earliest_asgchange_date.documentation = new vscode.MarkdownString('This function used to get the earliest assignment change |Return Data Type : Date');

                    const l_get_element_entry = new vscode.CompletionItem('get_element_entry', vscode.CompletionItemKind.Function);
                    l_get_element_entry.insertText = new vscode.SnippetString(' get_element_entry()');
                    l_get_element_entry.documentation = new vscode.MarkdownString('Fetches the element entry | Return Data Type : Number');

                    const l_get_end_date = new vscode.CompletionItem('get_end_date', vscode.CompletionItemKind.Function);
                    l_get_end_date.insertText = new vscode.SnippetString(' get_end_date(${1:Start Date}, ${2:Period Length}, ${3:Period UOM})');
                    l_get_end_date.documentation = new vscode.MarkdownString('Calculates the end date based on start date and duration | Return Data Type : Date');

                    const l_get_enrt_dtls = new vscode.CompletionItem('get_enrt_dtls', vscode.CompletionItemKind.Function);
                    l_get_enrt_dtls.insertText = new vscode.SnippetString(' get_enrt_dtls(${1:Plan Name}, ${2:Enrollment Start Date}, ${3:Enrollment End Date}, ${4:Last Accrual Run})');
                    l_get_enrt_dtls.documentation = new vscode.MarkdownString('This formula function returns details of plan enrollment record | Return Data Type : Number');

                    const l_get_entitlements = new vscode.CompletionItem('get_entitlements', vscode.CompletionItemKind.Function);
                    l_get_entitlements.insertText = new vscode.SnippetString(' get_entitlements(${1:Plan Name[...]}, ${2:Band Name[...]}, ${3:Band Percentage[...]}, ${4:Start Date[...]}, ${5:End Date[...]})');
                    l_get_entitlements.documentation = new vscode.MarkdownString('This formula function returns entitlements of a person | Return Data Type : Number');

                    const l_get_ent_name = new vscode.CompletionItem('get_ent_name', vscode.CompletionItemKind.Function);
                    l_get_ent_name.insertText = new vscode.SnippetString(' get_ent_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_ent_name.documentation = new vscode.MarkdownString('Get Enterprise Name | Return Data Type : Number');

                    const l_get_event_date = new vscode.CompletionItem('get_event_date', vscode.CompletionItemKind.Function);
                    l_get_event_date.insertText = new vscode.SnippetString(' get_event_date(${1:Start Date[...]}, ${2:End Date[...]}, ${3:Event Type[...]})');
                    l_get_event_date.documentation = new vscode.MarkdownString('This formula function gives duration between two dates | Return Data Type : Date');

                    const l_get_expenditure_type_name = new vscode.CompletionItem('get_expenditure_type_name', vscode.CompletionItemKind.Function);
                    l_get_expenditure_type_name.insertText = new vscode.SnippetString(' get_expenditure_type_name(${1:Expression ID}, ${2:Default Value})');
                    l_get_expenditure_type_name.documentation = new vscode.MarkdownString('Get expenditure type name | Return Data Type : Text');

                    const l_get_flow_param_value = new vscode.CompletionItem('get_flow_param_value', vscode.CompletionItemKind.Function);
                    l_get_flow_param_value.insertText = new vscode.SnippetString(' get_flow_param_value(${1:Base Parameter Name})');
                    l_get_flow_param_value.documentation = new vscode.MarkdownString('This function is for fetching the flow parameter value by providing the FLOW INSTANCE ID and BASE PARAMETER NAME | Return Data Type : Text');

                    const l_get_formated_date = new vscode.CompletionItem('get_formated_date', vscode.CompletionItemKind.Function);
                    l_get_formated_date.insertText = new vscode.SnippetString(' get_formated_date(${1:In Date}, ${2:Format})');
                    l_get_formated_date.documentation = new vscode.MarkdownString('Return formatted string date | Return Data Type : Text');

                    const l_get_formated_day_of_week = new vscode.CompletionItem('get_formated_day_of_week', vscode.CompletionItemKind.Function);
                    l_get_formated_day_of_week.insertText = new vscode.SnippetString(' get_formated_day_of_week(${1:In Day of Week})');
                    l_get_formated_day_of_week.documentation = new vscode.MarkdownString('Validate and format string day of week to three character uppercase day of week | Return Data Type : Text');

                    const l_get_formula_name = new vscode.CompletionItem('get_formula_name', vscode.CompletionItemKind.Function);
                    l_get_formula_name.insertText = new vscode.SnippetString(' get_formula_name(${1:Formula ID})');
                    l_get_formula_name.documentation = new vscode.MarkdownString('Returns the name of the formula with the specified FORMULA ID | Return Data Type : Text');

                    const l_get_fvalue_date = new vscode.CompletionItem('get_fvalue_date', vscode.CompletionItemKind.Function);
                    l_get_fvalue_date.insertText = new vscode.SnippetString(' get_fvalue_date(${1:Fast Formula ID}, ${2:Value Name}, ${3:Default Value})');
                    l_get_fvalue_date.documentation = new vscode.MarkdownString('Returns a value of a date from Rule Parameters table | Return Data Type : Date');

                    const l_get_fvalue_number = new vscode.CompletionItem('get_fvalue_number', vscode.CompletionItemKind.Function);
                    l_get_fvalue_number.insertText = new vscode.SnippetString(' get_fvalue_number(${1:Fast Formula ID}, ${2:Value Name}, ${3:Default Value})');
                    l_get_fvalue_number.documentation = new vscode.MarkdownString('Returns a value of a number from Rule Parameters table | Return Data Type : Number');

                    const l_get_fvalue_text = new vscode.CompletionItem('get_fvalue_text', vscode.CompletionItemKind.Function);
                    l_get_fvalue_text.insertText = new vscode.SnippetString(' get_fvalue_text(${1:Fast Formula ID}, ${2:Value Name}, ${3:Default Value})');
                    l_get_fvalue_text.documentation = new vscode.MarkdownString('Returns a value of a text from Rule Parameters table | Return Data Type : Text');

                    const l_get_geography_identifier = new vscode.CompletionItem('get_geography_identifier', vscode.CompletionItemKind.Function);
                    l_get_geography_identifier.insertText = new vscode.SnippetString(' get_geography_identifier(${1:Geography ID}, ${2:Geography Name}, ${3:Level}, ${4:Parent Geography ID[...]}, ${5:Provider[...]}, ${6:Subtype[...]}, ${7:Use[...]})');
                    l_get_geography_identifier.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_get_geography_name = new vscode.CompletionItem('get_geography_name', vscode.CompletionItemKind.Function);
                    l_get_geography_name.insertText = new vscode.SnippetString(' get_geography_name(${1:Geography ID}, ${2:Use[...]})');
                    l_get_geography_name.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_get_geo_std_name_by_user_code = new vscode.CompletionItem('get_geo_std_name_by_user_code', vscode.CompletionItemKind.Function);
                    l_get_geo_std_name_by_user_code.insertText = new vscode.SnippetString(' get_geo_std_name_by_user_code(${1:Geography Code})');
                    l_get_geo_std_name_by_user_code.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_get_grade_name = new vscode.CompletionItem('get_grade_name', vscode.CompletionItemKind.Function);
                    l_get_grade_name.insertText = new vscode.SnippetString(' get_grade_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_grade_name.documentation = new vscode.MarkdownString('Returns Grade name | Return Data Type : Number');

                    const l_get_hdr_text = new vscode.CompletionItem('get_hdr_text', vscode.CompletionItemKind.Function);
                    l_get_hdr_text.insertText = new vscode.SnippetString(' get_hdr_text(${1:Rule ID}, ${2:Column Name}, ${3:Default Value})');
                    l_get_hdr_text.documentation = new vscode.MarkdownString('Returns a value of a text from Rule Template table by Rule ID | Return Data Type : Text');

                    const l_get_home_city = new vscode.CompletionItem('get_home_city', vscode.CompletionItemKind.Function);
                    l_get_home_city.insertText = new vscode.SnippetString(' get_home_city(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_home_city.documentation = new vscode.MarkdownString('Get Home city | Return Data Type : Number');

                    const l_get_home_country = new vscode.CompletionItem('get_home_country', vscode.CompletionItemKind.Function);
                    l_get_home_country.insertText = new vscode.SnippetString(' get_home_country(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_home_country.documentation = new vscode.MarkdownString('Get Home country | Return Data Type : Number');

                    const l_get_is_date_same_as_dow = new vscode.CompletionItem('get_is_date_same_as_dow', vscode.CompletionItemKind.Function);
                    l_get_is_date_same_as_dow.insertText = new vscode.SnippetString(' get_is_date_same_as_dow(${1:Input Date}, ${2:In Day Of Week})');
                    l_get_is_date_same_as_dow.documentation = new vscode.MarkdownString('Compare day of week from date to string day of week | Return Data Type : Text');

                    const l_get_job_name = new vscode.CompletionItem('get_job_name', vscode.CompletionItemKind.Function);
                    l_get_job_name.insertText = new vscode.SnippetString(' get_job_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_job_name.documentation = new vscode.MarkdownString('Get Job name | Return Data Type : Number');

                    const l_get_legentity_name = new vscode.CompletionItem('get_legentity_name', vscode.CompletionItemKind.Function);
                    l_get_legentity_name.insertText = new vscode.SnippetString(' get_legentity_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_legentity_name.documentation = new vscode.MarkdownString('Get Legal Entity name | Return Data Type : Number');

                    const l_get_locaton_name = new vscode.CompletionItem('get_locaton_name', vscode.CompletionItemKind.Function);
                    l_get_locaton_name.insertText = new vscode.SnippetString(' get_locaton_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_locaton_name.documentation = new vscode.MarkdownString('Get Location name | Return Data Type : Number');

                    const l_get_lookup_meaning = new vscode.CompletionItem('get_lookup_meaning', vscode.CompletionItemKind.Function);
                    l_get_lookup_meaning.insertText = new vscode.SnippetString(' get_lookup_meaning(${1:Lookup Type}, ${2:Lookup Code}, ${3:Default Meaning})');
                    l_get_lookup_meaning.documentation = new vscode.MarkdownString('Returns the lookup meaning for the specified lookup type and lookup code Returns the default meaning if there is no meaning for the lookup type and lookup code | Return Data Type : Text');

                    const l_get_measure_from_time = new vscode.CompletionItem('get_measure_from_time', vscode.CompletionItemKind.Function);
                    l_get_measure_from_time.insertText = new vscode.SnippetString(' get_measure_from_time(${1:Start Time}, ${2:Stop Time})');
                    l_get_measure_from_time.documentation = new vscode.MarkdownString('This function gets the difference between two dates in hours and minutes | Return Data Type : Number');

                    const l_get_mesg = new vscode.CompletionItem('get_mesg', vscode.CompletionItemKind.Function);
                    l_get_mesg.insertText = new vscode.SnippetString(' get_mesg(${1:App Name}, ${2:Message Name}, ${3:Token1[...]}, ${4:Value1[...]}, ${5:Token2[...]}, ${6:Value2[...]}, ${7:Token3[...]}, ${8:Value3[...]}, ${9:Token4[...]}, ${10:Value4[...]}, ${11:Token5[...]}, ${12:Value5[...]})');
                    l_get_mesg.documentation = new vscode.MarkdownString('Returns an expanded message string for a specified message name and token values | Return Data Type : Text');

                    const l_get_mgr_name = new vscode.CompletionItem('get_mgr_name', vscode.CompletionItemKind.Function);
                    l_get_mgr_name.insertText = new vscode.SnippetString(' get_mgr_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_mgr_name.documentation = new vscode.MarkdownString('Get Manager Name | Return Data Type : Number');

                    const l_get_msg_attribute = new vscode.CompletionItem('get_msg_attribute', vscode.CompletionItemKind.Function);
                    l_get_msg_attribute.insertText = new vscode.SnippetString(' get_msg_attribute(${1:Message Attribute Name})');
                    l_get_msg_attribute.documentation = new vscode.MarkdownString('Format message attribute for output | Return Data Type : Text');

                    const l_get_msg_severity = new vscode.CompletionItem('get_msg_severity', vscode.CompletionItemKind.Function);
                    l_get_msg_severity.insertText = new vscode.SnippetString(' get_msg_severity(${1:Message Severity})');
                    l_get_msg_severity.documentation = new vscode.MarkdownString('Format message severity for output | Return Data Type : Text');

                    const l_get_net_accrual = new vscode.CompletionItem('get_net_accrual', vscode.CompletionItemKind.Function);
                    l_get_net_accrual.insertText = new vscode.SnippetString(' get_net_accrual(${1:Accrual Plan ID}, ${2:Accrual Start Date}, ${3:Calculation Date}, ${4:Accrual Latest Balance})');
                    l_get_net_accrual.documentation = new vscode.MarkdownString('This function returns the Net Accrual amount | Return Data Type : Number');

                    const l_get_number = new vscode.CompletionItem('get_number', vscode.CompletionItemKind.Function);
                    l_get_number.insertText = new vscode.SnippetString(' get_number(${1:Name})');
                    l_get_number.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_get_org_name = new vscode.CompletionItem('get_org_name', vscode.CompletionItemKind.Function);
                    l_get_org_name.insertText = new vscode.SnippetString(' get_org_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_org_name.documentation = new vscode.MarkdownString('Get Department name | Return Data Type : Number');

                    const l_get_other_net_contribution = new vscode.CompletionItem('get_other_net_contribution', vscode.CompletionItemKind.Function);
                    l_get_other_net_contribution.insertText = new vscode.SnippetString(' get_other_net_contribution(${1:Start Date}, ${2:Calculation Date})');
                    l_get_other_net_contribution.documentation = new vscode.MarkdownString('This function returns the Other contribution amount | Return Data Type : Number');

                    const l_get_output_msg = new vscode.CompletionItem('get_output_msg', vscode.CompletionItemKind.Function);
                    l_get_output_msg.insertText = new vscode.SnippetString(' get_output_msg(${1:App Short Name}, ${2:Message Name})');
                    l_get_output_msg.documentation = new vscode.MarkdownString('Format message code and tokens for output | Return Data Type : Text');

                    const l_get_output_msg1 = new vscode.CompletionItem('get_output_msg1', vscode.CompletionItemKind.Function);
                    l_get_output_msg1.insertText = new vscode.SnippetString(' get_output_msg1(${1:App Short Name}, ${2:Message Name}, ${3:Token1 Name}, ${4:Token1 Value})');
                    l_get_output_msg1.documentation = new vscode.MarkdownString('Format message code and tokens for output | Return Data Type : Text');

                    const l_get_output_msg2 = new vscode.CompletionItem('get_output_msg2', vscode.CompletionItemKind.Function);
                    l_get_output_msg2.insertText = new vscode.SnippetString(' get_output_msg2(${1:App Short Name}, ${2:Message Name}, ${3:Token1 Name}, ${4:Token1 Value}, ${5:Token2 Name}, ${6:Token2 Value})');
                    l_get_output_msg2.documentation = new vscode.MarkdownString('Format message code and tokens for output | Return Data Type : Text');

                    const l_get_output_msg3 = new vscode.CompletionItem('get_output_msg3', vscode.CompletionItemKind.Function);
                    l_get_output_msg3.insertText = new vscode.SnippetString(' get_output_msg3(${1:App Short Name}, ${2:Message Name}, ${3:Token1 Name}, ${4:Token1 Value}, ${5:Token2 Name}, ${6:Token2 Value}, ${7:Token3 Name}, ${8:Token3 Value})');
                    l_get_output_msg3.documentation = new vscode.MarkdownString('Format message code and three tokens for output | Return Data Type : Text');

                    const l_get_output_msg4 = new vscode.CompletionItem('get_output_msg4', vscode.CompletionItemKind.Function);
                    l_get_output_msg4.insertText = new vscode.SnippetString(' get_output_msg4(${1:App Short Name}, ${2:Message Name}, ${3:Token1 Name}, ${4:Token1 Value}, ${5:Token2 Name}, ${6:Token2 Value}, ${7:Token3 Name}, ${8:Token3 Value}, ${9:Token4 Name}, ${10:Token4 Value})');
                    l_get_output_msg4.documentation = new vscode.MarkdownString('Format message code and four tokens for output | Return Data Type : Text');

                    const l_get_parameter_value = new vscode.CompletionItem('get_parameter_value', vscode.CompletionItemKind.Function);
                    l_get_parameter_value.insertText = new vscode.SnippetString(' get_parameter_value(${1:Name})');
                    l_get_parameter_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_get_parameter_value_date = new vscode.CompletionItem('get_parameter_value_date', vscode.CompletionItemKind.Function);
                    l_get_parameter_value_date.insertText = new vscode.SnippetString(' get_parameter_value_date(${1:Name})');
                    l_get_parameter_value_date.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Date');

                    const l_get_parameter_value_number = new vscode.CompletionItem('get_parameter_value_number', vscode.CompletionItemKind.Function);
                    l_get_parameter_value_number.insertText = new vscode.SnippetString(' get_parameter_value_number(${1:Name})');
                    l_get_parameter_value_number.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_get_payroll_details = new vscode.CompletionItem('get_payroll_details', vscode.CompletionItemKind.Function);
                    l_get_payroll_details.insertText = new vscode.SnippetString(' get_payroll_details(${1:Payroll ID}, ${2:Date in Period})');
                    l_get_payroll_details.documentation = new vscode.MarkdownString('Function to retrieve the Payroll details | Return Data Type : Number');

                    const l_get_payroll_dtrange = new vscode.CompletionItem('get_payroll_dtrange', vscode.CompletionItemKind.Function);
                    l_get_payroll_dtrange.insertText = new vscode.SnippetString(' get_payroll_dtrange(${1:Payroll ID})');
                    l_get_payroll_dtrange.documentation = new vscode.MarkdownString('Function used to fetch the date range of the PAYROLL | Return Data Type : Number');

                    const l_get_payroll_ID = new vscode.CompletionItem('get_payroll_ID', vscode.CompletionItemKind.Function);
                    l_get_payroll_ID.insertText = new vscode.SnippetString(' get_payroll_ID(${1:Date in Period})');
                    l_get_payroll_ID.documentation = new vscode.MarkdownString('This function is used to get the Payroll ID | Return Data Type : Number');

                    const l_get_payroll_period = new vscode.CompletionItem('get_payroll_period', vscode.CompletionItemKind.Function);
                    l_get_payroll_period.insertText = new vscode.SnippetString(' get_payroll_period(${1:Date in Period})');
                    l_get_payroll_period.documentation = new vscode.MarkdownString('Function to get the payroll period details| Return Data Type : Number');

                    const l_get_pay_availability = new vscode.CompletionItem('get_pay_availability', vscode.CompletionItemKind.Function);
                    l_get_pay_availability.insertText = new vscode.SnippetString(' get_pay_availability(${1:Resource Type[...]}, ${2:Period Start[...]}, ${3:Period End[...]}, ${4:Use Schedule Assignment[...]}, ${5:Use Schedule Inh[...]}, ${6:Include Noshift[...]}, ${7:Include Calender Events[...]}, ${8:Calculation Units[...]}, ${9:Get Full Pay Period[...]}, ${10:Use Working Hour Method[...]}, ${11:Default Hours Per Day[...]}, ${12:Default Start Time[...]}, ${13:Default Work Week[...]})');
                    l_get_pay_availability.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_get_period_dates = new vscode.CompletionItem('get_period_dates', vscode.CompletionItemKind.Function);
                    l_get_period_dates.insertText = new vscode.SnippetString(' get_period_dates(${1:Base Start Date}, ${2:Period Length}, ${3:Period Units}, ${4:Date in Period})');
                    l_get_period_dates.documentation = new vscode.MarkdownString('Function to get the payroll period dates| Return Data Type : Number');

                    const l_get_person_transfer_status = new vscode.CompletionItem('get_person_transfer_status', vscode.CompletionItemKind.Function);
                    l_get_person_transfer_status.insertText = new vscode.SnippetString(' get_person_transfer_status()');
                    l_get_person_transfer_status.documentation = new vscode.MarkdownString('Function to find is the PERSON had TRANSFER used in fast formula| Return Data Type : Text');

                    const l_get_plan_balance = new vscode.CompletionItem('get_plan_balance', vscode.CompletionItemKind.Function);
                    l_get_plan_balance.insertText = new vscode.SnippetString(' get_plan_balance(${1:Plan Name[...]})');
                    l_get_plan_balance.documentation = new vscode.MarkdownString('This formula function returns accrual balance of a plan| Return Data Type : Number');

                    const l_get_position_name = new vscode.CompletionItem('get_position_name', vscode.CompletionItemKind.Function);
                    l_get_position_name.insertText = new vscode.SnippetString(' get_position_name(${1:Assignment ID}, ${2:Calculation Date}, ${3:Value}, ${4:Name})');
                    l_get_position_name.documentation = new vscode.MarkdownString('Get Position Name| Return Data Type : Number');

                    const l_get_project_number = new vscode.CompletionItem('get_project_number', vscode.CompletionItemKind.Function);
                    l_get_project_number.insertText = new vscode.SnippetString(' get_project_number(${1:ID}, ${2:Default Value})');
                    l_get_project_number.documentation = new vscode.MarkdownString('Get project number| Return Data Type : Text');

                    const l_get_rate = new vscode.CompletionItem('get_rate', vscode.CompletionItemKind.Function);
                    l_get_rate.insertText = new vscode.SnippetString(' get_rate(${1:From Currency}, ${2:To Currency}, ${3:Rate Type}, ${4:Default Rate[...]})');
                    l_get_rate.documentation = new vscode.MarkdownString('Returns the rate between the two currencies for a given conversion date and rate type | Return Data Type : Number');

                    const l_get_rate_type = new vscode.CompletionItem('get_rate_type', vscode.CompletionItemKind.Function);
                    l_get_rate_type.insertText = new vscode.SnippetString(' get_rate_type(${1:Processing Type})');
                    l_get_rate_type.documentation = new vscode.MarkdownString('Returns the Rate Type | Return Data Type : Text');

                    const l_get_rating_level = new vscode.CompletionItem('get_rating_level', vscode.CompletionItemKind.Function);
                    l_get_rating_level.insertText = new vscode.SnippetString(' get_rating_level(${1:Assignment ID}, ${2:Calculation Date})');
                    l_get_rating_level.documentation = new vscode.MarkdownString('Returns Value, Name | Return Data Type : Number');

                    const l_get_reported_hours = new vscode.CompletionItem('get_reported_hours', vscode.CompletionItemKind.Function);
                    l_get_reported_hours.insertText = new vscode.SnippetString(' get_reported_hours(${1:Person Assignment ID})');
                    l_get_reported_hours.documentation = new vscode.MarkdownString('This function gets Time and Labor reported hours | Return Data Type : Number');

                    const l_get_retro_element = new vscode.CompletionItem('get_retro_element', vscode.CompletionItemKind.Function);
                    l_get_retro_element.insertText = new vscode.SnippetString(' get_retro_element()');
                    l_get_retro_element.documentation = new vscode.MarkdownString('Function to get the retro element details | Return Data Type : Number');

                    const l_get_rule_hdr_text = new vscode.CompletionItem('get_rule_hdr_text', vscode.CompletionItemKind.Function);
                    l_get_rule_hdr_text.insertText = new vscode.SnippetString(' get_rule_hdr_text(${1:Fast formula ID}, ${2:Column Name}, ${3:Default Value})');
                    l_get_rule_hdr_text.documentation = new vscode.MarkdownString('Returns a value of a text from Rule table| Return Data Type : Text');

                    const l_get_rvalue_date = new vscode.CompletionItem('get_rvalue_date', vscode.CompletionItemKind.Function);
                    l_get_rvalue_date.insertText = new vscode.SnippetString(' get_rvalue_date(${1:Rule ID}, ${2:Value Name}, ${3:Default Value})');
                    l_get_rvalue_date.documentation = new vscode.MarkdownString('Returns a value of a date from Rule table by Rule ID| Return Data Type : Date');

                    const l_get_rvalue_number = new vscode.CompletionItem('get_rvalue_number', vscode.CompletionItemKind.Function);
                    l_get_rvalue_number.insertText = new vscode.SnippetString(' get_rvalue_number(${1:Rule ID}, ${2:Value Name}, ${3:Default Value})');
                    l_get_rvalue_number.documentation = new vscode.MarkdownString('Returns a value of a number from Rule table by Rule ID| Return Data Type : Number');

                    const l_get_rvalue_text = new vscode.CompletionItem('get_rvalue_text', vscode.CompletionItemKind.Function);
                    l_get_rvalue_text.insertText = new vscode.SnippetString(' get_rvalue_text(${1:Rule ID}, ${2:Value Name}, ${3:Default Value})');
                    l_get_rvalue_text.documentation = new vscode.MarkdownString('Returns a value of a text from Rule table by Rule ID| Return Data Type : Text');

                    const l_get_start_date = new vscode.CompletionItem('get_start_date', vscode.CompletionItemKind.Function);
                    l_get_start_date.insertText = new vscode.SnippetString(' get_start_date(${1:Accrual Start Date}, ${2:Turn of Year Date})');
                    l_get_start_date.documentation = new vscode.MarkdownString('Calculates the adjusted start date for accruals, by checking for element entries attached to an accrual plan which have not yet been processed in a payroll run| Return Data Type : Date');

                    const l_get_table_value = new vscode.CompletionItem('get_table_value', vscode.CompletionItemKind.Function);
                    l_get_table_value.insertText = new vscode.SnippetString(' get_table_value(${1:Table Name}, ${2:Column Name}, ${3:Row Value}, ${4:Effective Date}, ${5:Group Level[...]}, ${6:Default Value[...]})');
                    l_get_table_value.documentation = new vscode.MarkdownString('Returns the value of a cell in a user-defined table on the effective date of the session or process| Return Data Type : Text');

                    const l_get_task_number = new vscode.CompletionItem('get_task_number', vscode.CompletionItemKind.Function);
                    l_get_task_number.insertText = new vscode.SnippetString(' get_task_number(${1:ID}, ${2:Default Value})');
                    l_get_task_number.documentation = new vscode.MarkdownString('Returns Task Number| Return Data Type : Number');

                    const l_get_termination_date = new vscode.CompletionItem('get_termination_date', vscode.CompletionItemKind.Function);
                    l_get_termination_date.insertText = new vscode.SnippetString(' get_termination_date()');
                    l_get_termination_date.documentation = new vscode.MarkdownString('Calculates the Termination Date| Return Data Type : Date');

                    const l_get_text = new vscode.CompletionItem('get_text', vscode.CompletionItemKind.Function);
                    l_get_text.insertText = new vscode.SnippetString(' get_text(${1:Name})');
                    l_get_text.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Text');

                    const l_get_value_by_criteria = new vscode.CompletionItem('get_value_by_criteria', vscode.CompletionItemKind.Function);
                    l_get_value_by_criteria.insertText = new vscode.SnippetString(' get_value_by_criteria(${1:Rate Def Name}, ${2:Out Periodicity}, ${3:Range Value}, ${4:Base Value}, ${5:Factor}, ${6:Range Offset})');
                    l_get_value_by_criteria.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_get_value_set = new vscode.CompletionItem('get_value_set', vscode.CompletionItemKind.Function);
                    l_get_value_set.insertText = new vscode.SnippetString(' get_value_set(${1:Value Set Code}, ${2:Binds[...]})');
                    l_get_value_set.documentation = new vscode.MarkdownString('Returns the first record of the given value set for the bind parse| Return Data Type : Text');

                    const l_get_working_days = new vscode.CompletionItem('get_working_days', vscode.CompletionItemKind.Function);
                    l_get_working_days.insertText = new vscode.SnippetString(' get_working_days(${1:Start Date}, ${2:End Date})');
                    l_get_working_days.documentation = new vscode.MarkdownString('Gets the number of working days in a given period| Return Data Type : Number');

                    const l_get_wrk_date = new vscode.CompletionItem('get_wrk_date', vscode.CompletionItemKind.Function);
                    l_get_wrk_date.insertText = new vscode.SnippetString(' get_wrk_date(${1:Fast formula ID}, ${2:Parameter Name}, ${3:Parameter Sequence}, ${4:Default Value})');
                    l_get_wrk_date.documentation = new vscode.MarkdownString('Returns value of session work date variable| Return Data Type : Date');

                    const l_get_wrk_num = new vscode.CompletionItem('get_wrk_num', vscode.CompletionItemKind.Function);
                    l_get_wrk_num.insertText = new vscode.SnippetString(' get_wrk_num(${1:Fast formula ID}, ${2:Parameter Name}, ${3:Parameter Sequence}, ${4:Default Value})');
                    l_get_wrk_num.documentation = new vscode.MarkdownString('Returns value of session work numeric variable| Return Data Type : Number');

                    const l_get_wrk_text = new vscode.CompletionItem('get_wrk_text', vscode.CompletionItemKind.Function);
                    l_get_wrk_text.insertText = new vscode.SnippetString(' get_wrk_text(${1:Fast formula ID}, ${2:Parameter Name}, ${3:Parameter Sequence}, ${4:Default Value})');
                    l_get_wrk_text.documentation = new vscode.MarkdownString('Returns value of session work text variable| Return Data Type : Text');

                    const l_greatest = new vscode.CompletionItem('greatest', vscode.CompletionItemKind.Function);
                    l_greatest.insertText = new vscode.SnippetString(' greatest(${1:Number1}, ${2:Number2[...]})');
                    l_greatest.documentation = new vscode.MarkdownString('Returns the greatest number from among its operands| Return Data Type : Number');

                    const l_hrc_create_bo_extract = new vscode.CompletionItem('hrc_create_bo_extract', vscode.CompletionItemKind.Function);
                    l_hrc_create_bo_extract.insertText = new vscode.SnippetString(' hrc_create_bo_extract(${1:Object Name}, ${2:Extract Type})');
                    l_hrc_create_bo_extract.documentation = new vscode.MarkdownString('This function tests extract proc| Return Data Type : Number');

                    const l_hr_get_table_value = new vscode.CompletionItem('hr_get_table_value', vscode.CompletionItemKind.Function);
                    l_hr_get_table_value.insertText = new vscode.SnippetString(' hr_get_table_value(${1:Object Name}, ${2:Extract Type})');
                    l_hr_get_table_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Text');

                    const l_hr_trace = new vscode.CompletionItem('hr_trace', vscode.CompletionItemKind.Function);
                    l_hr_trace.insertText = new vscode.SnippetString(' hr_trace(${1:Trace Data})');
                    l_hr_trace.documentation = new vscode.MarkdownString('Write a message to the HR_UTILITY logging system from a formula| Return Data Type : Text');

                    const l_initcap = new vscode.CompletionItem('initcap', vscode.CompletionItemKind.Function);
                    l_initcap.insertText = new vscode.SnippetString(' initcap(${1:Text String})');
                    l_initcap.documentation = new vscode.MarkdownString('Returns the result of modifying a string so that each word within the string begins with a capital letter followed by lowercase letters| Return Data Type : Text');

                    const l_init_util = new vscode.CompletionItem('init_util', vscode.CompletionItemKind.Function);
                    l_init_util.insertText = new vscode.SnippetString(' init_util(${1:Fast formula ID}, ${2:Rule ID})');
                    l_init_util.documentation = new vscode.MarkdownString('Initialize HWM_FF_UTIL and prepare HWM_RULE_FF_WORKAREA| Return Data Type : Number');

                    const l_instr = new vscode.CompletionItem('instr', vscode.CompletionItemKind.Function);
                    l_instr.insertText = new vscode.SnippetString(' instr(${1:Text String}, ${2:Search String})');
                    l_instr.documentation = new vscode.MarkdownString('Returns the character position of a particular occurrence of a substring within a string| Return Data Type : Number');

                    const l_instrb = new vscode.CompletionItem('instrb', vscode.CompletionItemKind.Function);
                    l_instrb.insertText = new vscode.SnippetString(' instrb(${1:Text String}, ${2:Search String})');
                    l_instrb.documentation = new vscode.MarkdownString('Returns the byte position of a particular occurrence of a substring within a string| Return Data Type : Number');

                    const l_isnull = new vscode.CompletionItem('isnull', vscode.CompletionItemKind.Function);
                    l_isnull.insertText = new vscode.SnippetString(' isnull(${1:Value})');
                    l_isnull.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Text');

                    const l_is_date_null = new vscode.CompletionItem('is_date_null', vscode.CompletionItemKind.Function);
                    l_is_date_null.insertText = new vscode.SnippetString(' is_date_null(${1:Value})');
                    l_is_date_null.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Text');

                    const l_is_number_null = new vscode.CompletionItem('is_number_null', vscode.CompletionItemKind.Function);
                    l_is_number_null.insertText = new vscode.SnippetString(' is_number_null(${1:Value})');
                    l_is_number_null.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Text');

                    const l_is_text_null = new vscode.CompletionItem('is_text_null', vscode.CompletionItemKind.Function);
                    l_is_text_null.insertText = new vscode.SnippetString(' is_text_null(${1:Value})');
                    l_is_text_null.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Text');

                    const l_iterative_get_binary_guess = new vscode.CompletionItem('iterative_get_binary_guess', vscode.CompletionItemKind.Function);
                    l_iterative_get_binary_guess.insertText = new vscode.SnippetString(' iterative_get_binary_guess(${1:Calculation Mode})');
                    l_iterative_get_binary_guess.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_iterative_get_high_value = new vscode.CompletionItem('iterative_get_high_value', vscode.CompletionItemKind.Function);
                    l_iterative_get_high_value.insertText = new vscode.SnippetString(' iterative_get_high_value()');
                    l_iterative_get_high_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_iterative_get_interp_guess = new vscode.CompletionItem('iterative_get_interp_guess', vscode.CompletionItemKind.Function);
                    l_iterative_get_interp_guess.insertText = new vscode.SnippetString(' iterative_get_interp_guess(${1:Result Value})');
                    l_iterative_get_interp_guess.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_iterative_get_low_value = new vscode.CompletionItem('iterative_get_low_value', vscode.CompletionItemKind.Function);
                    l_iterative_get_low_value.insertText = new vscode.SnippetString(' iterative_get_low_value()');
                    l_iterative_get_low_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_iterative_get_target_value = new vscode.CompletionItem('iterative_get_target_value', vscode.CompletionItemKind.Function);
                    l_iterative_get_target_value.insertText = new vscode.SnippetString(' iterative_get_target_value()');
                    l_iterative_get_target_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_iterative_initialise = new vscode.CompletionItem('iterative_initialise', vscode.CompletionItemKind.Function);
                    l_iterative_initialise.insertText = new vscode.SnippetString(' iterative_initialise(${1:Target Value})');
                    l_iterative_initialise.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_iterative_is_amount_set = new vscode.CompletionItem('iterative_is_amount_set', vscode.CompletionItemKind.Function);
                    l_iterative_is_amount_set.insertText = new vscode.SnippetString(' iterative_is_amount_set()');
                    l_iterative_is_amount_set.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Number');

                    const l_last_day = new vscode.CompletionItem('last_day', vscode.CompletionItemKind.Function);
                    l_last_day.insertText = new vscode.SnippetString(' last_day(${1:Date})');
                    l_last_day.documentation = new vscode.MarkdownString('Returns the last day of the month a date falls within| Return Data Type : Date');

                    const l_least = new vscode.CompletionItem('least', vscode.CompletionItemKind.Function);
                    l_least.insertText = new vscode.SnippetString(' least(${1:Number1}, ${2:Number2[...]})');
                    l_least.documentation = new vscode.MarkdownString('Returns the smallest number from among its operands| Return Data Type : Number');

                    const l_length = new vscode.CompletionItem('length', vscode.CompletionItemKind.Function);
                    l_length.insertText = new vscode.SnippetString(' length(${1:Text String})');
                    l_length.documentation = new vscode.MarkdownString('Returns the number of characters in a string| Return Data Type : Number');

                    const l_lengthb = new vscode.CompletionItem('lengthb', vscode.CompletionItemKind.Function);
                    l_lengthb.insertText = new vscode.SnippetString(' lengthb(${1:Text String})');
                    l_lengthb.documentation = new vscode.MarkdownString('Returns the number of characters in a bytes| Return Data Type : Number');

                    const l_lower = new vscode.CompletionItem('lower', vscode.CompletionItemKind.Function);
                    l_lower.insertText = new vscode.SnippetString(' lower(${1:Text String})');
                    l_lower.documentation = new vscode.MarkdownString('Returns the result of converting a string to lowercase| Return Data Type : Text');

                    const l_lpad = new vscode.CompletionItem('lpad', vscode.CompletionItemKind.Function);
                    l_lpad.insertText = new vscode.SnippetString(' lpad(${1:Text String}, ${2:Length}, ${3:Padding[...]})');
                    l_lpad.documentation = new vscode.MarkdownString('Returns the result of left-padding a string to a specified length. If a padding string is not specified then spaces are used for padding| Return Data Type : Text');

                    const l_ltrim = new vscode.CompletionItem('ltrim', vscode.CompletionItemKind.Function);
                    l_ltrim.insertText = new vscode.SnippetString(' ltrim(${1:Text String}, ${2:Set[...]})');
                    l_ltrim.documentation = new vscode.MarkdownString('Returns the result of removing characters from the left of string. If a set of characters to remove is not specified then spaces are removed| Return Data Type : Text');

                    const l_mod = new vscode.CompletionItem('mod', vscode.CompletionItemKind.Function);
                    l_mod.insertText = new vscode.SnippetString(' mod(${1:Number1}, ${2:Number2})');
                    l_mod.documentation = new vscode.MarkdownString('Returns the remainder from dividing its first argument by its second argument. Returns the first argument if the second is zero| Return Data Type : Number');

                    const l_months_between = new vscode.CompletionItem('months_between', vscode.CompletionItemKind.Function);
                    l_months_between.insertText = new vscode.SnippetString(' months_between(${1:To Date}, ${2:From Date})');
                    l_months_between.documentation = new vscode.MarkdownString('Returns the number of months between two dates| Return Data Type : Number');

                    const l_new_time = new vscode.CompletionItem('new_time', vscode.CompletionItemKind.Function);
                    l_new_time.insertText = new vscode.SnippetString(' new_time(${1:Date}, ${2:TimeZone From}, ${2:TimeZone To})');
                    l_new_time.documentation = new vscode.MarkdownString('Returns a date in a specified time zone as a date in another time zone| Return Data Type : Date');

                    const l_next_day = new vscode.CompletionItem('next_day', vscode.CompletionItemKind.Function);
                    l_next_day.insertText = new vscode.SnippetString(' next_day(${1:Date}, ${2:Day})');
                    l_next_day.documentation = new vscode.MarkdownString('Returns the date corresponding first week day after a date| Return Data Type : Date');

                    const l_num_to_char = new vscode.CompletionItem('num_to_char', vscode.CompletionItemKind.Function);
                    l_num_to_char.insertText = new vscode.SnippetString(' num_to_char(${1:Date}, ${2:Day})');
                    l_num_to_char.documentation = new vscode.MarkdownString('Returns the result of converting a number to a string in a specified format| Return Data Type : Text');

                    const l_pay_edn_publish_event = new vscode.CompletionItem('pay_edn_publish_event', vscode.CompletionItemKind.Function);
                    l_pay_edn_publish_event.insertText = new vscode.SnippetString(' pay_edn_publish_event(${1:Namespace})');
                    l_pay_edn_publish_event.documentation = new vscode.MarkdownString('Oracle Inbuilt Function| Return Data Type : Text');

                    const l_pay_get_rate_type = new vscode.CompletionItem('pay_get_rate_type', vscode.CompletionItemKind.Function);
                    l_pay_get_rate_type.insertText = new vscode.SnippetString(' pay_get_rate_type(${1:Processing Type})');
                    l_pay_get_rate_type.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_pay_internal_log_write = new vscode.CompletionItem('pay_internal_log_write', vscode.CompletionItemKind.Function);
                    l_pay_internal_log_write.insertText = new vscode.SnippetString(' pay_internal_log_write(${1:Print String})');
                    l_pay_internal_log_write.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_pay_log_error = new vscode.CompletionItem('pay_log_error', vscode.CompletionItemKind.Function);
                    l_pay_log_error.insertText = new vscode.SnippetString(' pay_log_error(${1:Name}, ${2:Token1[...]}, ${3:Token2[...]}, ${4:Token3[...]})');
                    l_pay_log_error.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_pay_log_warning = new vscode.CompletionItem('pay_log_warning', vscode.CompletionItemKind.Function);
                    l_pay_log_warning.insertText = new vscode.SnippetString(' pay_log_warning(${1:Name}, ${2:Token1[...]}, ${3:Token2[...]}, ${4:Token3[...]})');
                    l_pay_log_warning.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_power = new vscode.CompletionItem('power', vscode.CompletionItemKind.Function);
                    l_power.insertText = new vscode.SnippetString(' power(${1:Number}, ${2:Exponent})');
                    l_power.documentation = new vscode.MarkdownString('Returns the result of raising a number to a power | Return Data Type : Number');

                    const l_raise_error = new vscode.CompletionItem('raise_error', vscode.CompletionItemKind.Function);
                    l_raise_error.insertText = new vscode.SnippetString(' raise_error(${1:Fast Formula ID}, ${2:Rule ID}, ${3:Message Text})');
                    l_raise_error.documentation = new vscode.MarkdownString('This function will raise error | Return Data Type : Number');

                    const l_rand = new vscode.CompletionItem('rand', vscode.CompletionItemKind.Function);
                    l_rand.insertText = new vscode.SnippetString(' rand(${1:Low}, ${2:High})');
                    l_rand.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_rand_seed = new vscode.CompletionItem('rand_seed', vscode.CompletionItemKind.Function);
                    l_rand_seed.insertText = new vscode.SnippetString(' rand_seed(${1:Number})');
                    l_rand_seed.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_rate_converter = new vscode.CompletionItem('rate_converter', vscode.CompletionItemKind.Function);
                    l_rate_converter.insertText = new vscode.SnippetString(' rate_converter(${1:Source Amount}, ${2:Source Periodicity}, ${3:Target Periodicity})');
                    l_rate_converter.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_rate_engine = new vscode.CompletionItem('rate_engine', vscode.CompletionItemKind.Function);
                    l_rate_engine.insertText = new vscode.SnippetString(' rate_engine(${1:Rate Def Name}, ${2:Range Value}, ${3:Base Value}, ${4:Factor}, ${5:Range Offset}, ${6:Ovr Periodicity}, ${7:Ovr Mode})');
                    l_rate_engine.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_rate_engine_init = new vscode.CompletionItem('rate_engine_init', vscode.CompletionItemKind.Function);
                    l_rate_engine_init.insertText = new vscode.SnippetString(' rate_engine_init()');
                    l_rate_engine_init.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_rate_engine_put_value = new vscode.CompletionItem('rate_engine_put_value', vscode.CompletionItemKind.Function);
                    l_rate_engine_put_value.insertText = new vscode.SnippetString(' rate_engine_put_value(${1:Name})');
                    l_rate_engine_put_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_remove_globals = new vscode.CompletionItem('remove_globals', vscode.CompletionItemKind.Function);
                    l_remove_globals.insertText = new vscode.SnippetString(' remove_globals()');
                    l_remove_globals.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_replace = new vscode.CompletionItem('replace', vscode.CompletionItemKind.Function);
                    l_replace.insertText = new vscode.SnippetString(' replace(${1:Text String}, ${2:Search String}, ${3:Replacement String[...]})');
                    l_replace.documentation = new vscode.MarkdownString('Returns the result of replacing a search string within a string by a replacement string | If no replacement string is specified, then the empty string is used as the replacement string | Return Data Type : Text');

                    const l_reset_accruals = new vscode.CompletionItem('reset_accruals', vscode.CompletionItemKind.Function);
                    l_reset_accruals.insertText = new vscode.SnippetString(' reset_accruals()');
                    l_reset_accruals.documentation = new vscode.MarkdownString('Determines whether the net accruals for an assignment should be recalculated from the beginning | Return Data Type : Text');

                    const l_round = new vscode.CompletionItem('round', vscode.CompletionItemKind.Function);
                    l_round.insertText = new vscode.SnippetString(' round(${1:Number}, ${2:Number of Decimal Places})');
                    l_round.documentation = new vscode.MarkdownString('Returns the result of rounding a number to a number of decimal places | The default number of decimal places is 0 | Return Data Type : Number');

                    const l_round_up = new vscode.CompletionItem('round_up', vscode.CompletionItemKind.Function);
                    l_round_up.insertText = new vscode.SnippetString(' round_up(${1:Number}, ${2:Number of Decimal Places})');
                    l_round_up.documentation = new vscode.MarkdownString('Returns the result of rounding a number up to a number of decimal places | Return Data Type : Number');

                    const l_rpad = new vscode.CompletionItem('rpad', vscode.CompletionItemKind.Function);
                    l_rpad.insertText = new vscode.SnippetString(' rpad(${1:Text String}, ${2:Length}, ${3:Padding[...]})');
                    l_rpad.documentation = new vscode.MarkdownString('Returns the result of right-padding a string to a specified lengt | If a padding string is not specified then spaces are used for padding | Return Data Type : Text');

                    const l_rtrim = new vscode.CompletionItem('rtrim', vscode.CompletionItemKind.Function);
                    l_rtrim.insertText = new vscode.SnippetString(' rtrim(${1:Text String}, ${2:Set[...]})');
                    l_rtrim.documentation = new vscode.MarkdownString('Returns the text string operand expr with all the right-most characters that appear in Set removed | If a set of characters to remove is not specified then spaces are removed | Return Data Type : Text');

                    const l_set_accrual_balance = new vscode.CompletionItem('set_accrual_balance', vscode.CompletionItemKind.Function);
                    l_set_accrual_balance.insertText = new vscode.SnippetString(' set_accrual_balance(${1:Element Type}, ${2:Element Type ID}, ${3:Input Value ID}, ${4:Accrual Band ID}, ${5:Absence Type ID}, ${6:Absence Attendance ID}, ${7:Start Date}), ${8:End Date}, ${9:Contributed Amount})');
                    l_set_accrual_balance.documentation = new vscode.MarkdownString('Function to set the accrual period wise balance | Return Data Type : Number');

                    const l_set_date = new vscode.CompletionItem('set_date', vscode.CompletionItemKind.Function);
                    l_set_date.insertText = new vscode.SnippetString(' set_date(${1:Name}, ${2:Date Value})');
                    l_set_date.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_set_number = new vscode.CompletionItem('set_number', vscode.CompletionItemKind.Function);
                    l_set_number.insertText = new vscode.SnippetString(' set_number(${1:Name}, ${2:Number Value})');
                    l_set_number.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_set_text = new vscode.CompletionItem('set_text', vscode.CompletionItemKind.Function);
                    l_set_text.insertText = new vscode.SnippetString(' set_text(${1:Name}, ${2:Text Value})');
                    l_set_text.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_set_wrk_date = new vscode.CompletionItem('set_wrk_date', vscode.CompletionItemKind.Function);
                    l_set_wrk_date.insertText = new vscode.SnippetString(' set_wrk_date(${1:Fast Formula ID}, ${2:Parameter Name}, ${3:Parameter Seq}, ${4:Parameter Value Date})');
                    l_set_wrk_date.documentation = new vscode.MarkdownString('Set session work date variable | Return Data Type : Number');

                    const l_set_wrk_num = new vscode.CompletionItem('set_wrk_num', vscode.CompletionItemKind.Function);
                    l_set_wrk_num.insertText = new vscode.SnippetString(' set_wrk_num(${1:Fast Formula ID}, ${2:Parameter Name}, ${3:Parameter Seq}, ${4:Parameter Value Number})');
                    l_set_wrk_num.documentation = new vscode.MarkdownString('Set session work numeric variable | Return Data Type : Number');

                    const l_set_wrk_text = new vscode.CompletionItem('set_wrk_text', vscode.CompletionItemKind.Function);
                    l_set_wrk_text.insertText = new vscode.SnippetString(' set_wrk_text(${1:Fast Formula ID}, ${2:Parameter Name}, ${3:Parameter Seq}, ${4:Parameter Value Number})');
                    l_set_wrk_text.documentation = new vscode.MarkdownString('Set session work text variable | Return Data Type : Number');

                    const l_std_annualized_rate_converter = new vscode.CompletionItem('std_annualized_rate_converter', vscode.CompletionItemKind.Function);
                    l_std_annualized_rate_converter.insertText = new vscode.SnippetString(' std_annualized_rate_converter(${1:Source Amount}, ${2:Source Periodicity}, ${3:Target Periodicity})');
                    l_std_annualized_rate_converter.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_substr = new vscode.CompletionItem('substr', vscode.CompletionItemKind.Function);
                    l_substr.insertText = new vscode.SnippetString(' substr(${1:Text String}, ${2:Position}, ${3:Length[...]})');
                    l_substr.documentation = new vscode.MarkdownString('Returns a substring of a string | The starting position and length are specified in units of whole characters | Return Data Type : Number');

                    const l_substrb = new vscode.CompletionItem('substrb', vscode.CompletionItemKind.Function);
                    l_substrb.insertText = new vscode.SnippetString(' substrb(${1:Text String}, ${2:Position}, ${3:Length[...]})');
                    l_substrb.documentation = new vscode.MarkdownString('Returns a substring of a string | The starting position and length are specified in units of bytes | Return Data Type : Number');

                    const l_taxability_rule_exists = new vscode.CompletionItem('taxability_rule_exists', vscode.CompletionItemKind.Function);
                    l_taxability_rule_exists.insertText = new vscode.SnippetString(' taxability_rule_exists(${1:Ignore Class}, ${2:Use Base Ee})');
                    l_taxability_rule_exists.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_time_hhmm_to_dec = new vscode.CompletionItem('time_hhmm_to_dec', vscode.CompletionItemKind.Function);
                    l_time_hhmm_to_dec.insertText = new vscode.SnippetString(' time_hhmm_to_dec(${1:Time})');
                    l_time_hhmm_to_dec.documentation = new vscode.MarkdownString('Converts time to decimal | Return Data Type : Number');

                    const l_to_char = new vscode.CompletionItem('to_char', vscode.CompletionItemKind.Function);
                    l_to_char.insertText = new vscode.SnippetString(' to_char(${1:Date}, ${2:Format})');
                    l_to_char.documentation = new vscode.MarkdownString('Returns the result of converting a date to a string in a specified format | Return Data Type : Number');

                    const l_to_date = new vscode.CompletionItem('to_date', vscode.CompletionItemKind.Function);
                    l_to_date.insertText = new vscode.SnippetString(' to_date(${1:Text String}, ${2:Format})');
                    l_to_date.documentation = new vscode.MarkdownString('Returns the result of converting a string to a date in a specified format | Return Data Type : Date');

                    const l_to_number = new vscode.CompletionItem('to_number', vscode.CompletionItemKind.Function);
                    l_to_number.insertText = new vscode.SnippetString(' to_number(${1:Text String})');
                    l_to_number.documentation = new vscode.MarkdownString('Returns the result of converting a string to a number | Return Data Type : Number');

                    const l_to_text = new vscode.CompletionItem('to_text', vscode.CompletionItemKind.Function);
                    l_to_text.insertText = new vscode.SnippetString(' to_text(${1:Date/Number}, ${2:Format})');
                    l_to_text.documentation = new vscode.MarkdownString('Returns the result of converting a Date/Number to a string in a specified format | Return Data Type : Number');

                    const l_translate = new vscode.CompletionItem('translate', vscode.CompletionItemKind.Function);
                    l_translate.insertText = new vscode.SnippetString(' translate(${1:Text String}, ${2:From String}, ${3:To String})');
                    l_translate.documentation = new vscode.MarkdownString('Returns the result of replacing source characters by corresponding target characters, within a string | Return Data Type : Text');

                    const l_trim = new vscode.CompletionItem('trim', vscode.CompletionItemKind.Function);
                    l_trim.insertText = new vscode.SnippetString(' trim(${1:Text String})');
                    l_trim.documentation = new vscode.MarkdownString('Returns the string formed by removing leading and trailing spaces from a string | Return Data Type : Number');

                    const l_trunc = new vscode.CompletionItem('trunc', vscode.CompletionItemKind.Function);
                    l_trunc.insertText = new vscode.SnippetString(' trunc()');
                    l_trunc.documentation = new vscode.MarkdownString('Returns a Date/Number truncated according to a unit of measure | Return Data Type : Date/Number');

                    const l_unit_converter = new vscode.CompletionItem('unit_converter', vscode.CompletionItemKind.Function);
                    l_unit_converter.insertText = new vscode.SnippetString(' unit_converter(${1:In_Unit[...]}, ${2:In_Uom[...]}, ${3:In_Reporting_Uom[...]})');
                    l_unit_converter.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_update_context_array = new vscode.CompletionItem('update_context_array', vscode.CompletionItemKind.Function);
                    l_update_context_array.insertText = new vscode.SnippetString(' update_context_array(${1:Name}, ${2:Value Text}, ${3:Name}, ${4:Value Date}, ${5:Name}, ${6:Value Number})');
                    l_update_context_array.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_update_parameter_array = new vscode.CompletionItem('update_parameter_array', vscode.CompletionItemKind.Function);
                    l_update_parameter_array.insertText = new vscode.SnippetString(' update_parameter_array(${1:Name}, ${2:Value Text/Date/Number})');
                    l_update_parameter_array.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_upper = new vscode.CompletionItem('upper', vscode.CompletionItemKind.Function);
                    l_upper.insertText = new vscode.SnippetString(' upper(${1:Text String})');
                    l_upper.documentation = new vscode.MarkdownString('Returns the result of converting a string to upper case | Return Data Type : Text');

                    const l_us_adjust_tax_balances = new vscode.CompletionItem('us_adjust_tax_balances', vscode.CompletionItemKind.Function);
                    l_us_adjust_tax_balances.insertText = new vscode.SnippetString(' us_adjust_tax_balances(${1:Jur Code}, ${2:Tax Type}, ${3:Mode}, ${4:125 Redns}, ${5:401 Redns}, ${6:403 Redns}, ${7:457 Redns}), ${8:Decare Redns}, ${9:Other Pretax Redns}, ${10:Gross}, ${11:Subj Nwhable}, ${12:Location}, ${13:Reduced Subj}, ${14:Subj}, ${15:Imputed})');
                    l_us_adjust_tax_balances.documentation = new vscode.MarkdownString('Function to adjust balances for wage accumulation | Return Data Type : Text');

                    const l_us_formula_logging = new vscode.CompletionItem('us_formula_logging', vscode.CompletionItemKind.Function);
                    l_us_formula_logging.insertText = new vscode.SnippetString(' us_formula_logging(${1:Print Message Code}, ${2:Print Message})');
                    l_us_formula_logging.documentation = new vscode.MarkdownString('Function to put debug message in extract fast formula | Return Data Type : Text');

                    const l_us_pr_ext_tax_code_count = new vscode.CompletionItem('us_pr_ext_tax_code_count', vscode.CompletionItemKind.Function);
                    l_us_pr_ext_tax_code_count.insertText = new vscode.SnippetString(' us_pr_ext_tax_code_count()');
                    l_us_pr_ext_tax_code_count.documentation = new vscode.MarkdownString('${1:Legislative Data Grouid}, ${2:Effective Date}, ${3:Tax Unit Id}, ${4:Payroll Action Id}, ${5:Tax Region}, ${6:State}, ${7:County}), ${8:City}, ${9:School District}, ${10:Tax Code}, ${11:Count Code} | Return Data Type : Number');

                    const l_us_state_abbreviation = new vscode.CompletionItem('us_state_abbreviation', vscode.CompletionItemKind.Function);
                    l_us_state_abbreviation.insertText = new vscode.SnippetString(' us_state_abbreviation(${1:State Name})');
                    l_us_state_abbreviation.documentation = new vscode.MarkdownString('Function to derive state abbreviation used in tax Extract | Return Data Type : Text');

                    const l_value_criteria_init = new vscode.CompletionItem('value_criteria_init', vscode.CompletionItemKind.Function);
                    l_value_criteria_init.insertText = new vscode.SnippetString(' value_criteria_init()');
                    l_value_criteria_init.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_value_criteria_put_value = new vscode.CompletionItem('value_criteria_put_value', vscode.CompletionItemKind.Function);
                    l_value_criteria_put_value.insertText = new vscode.SnippetString(' value_criteria_put_value(${1:Name}, ${2:Value}, ${3:Datatype})');
                    l_value_criteria_put_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_vx_calculate = new vscode.CompletionItem('vx_calculate', vscode.CompletionItemKind.Function);
                    l_vx_calculate.insertText = new vscode.SnippetString(' vx_calculate()');
                    l_vx_calculate.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Number');

                    const l_vx_get_form_value = new vscode.CompletionItem('vx_get_form_value', vscode.CompletionItemKind.Function);
                    l_vx_get_form_value.insertText = new vscode.SnippetString(' vx_get_form_value(${1:Tax ID}, ${2:Tax Type}, ${3:Parameter Name})');
                    l_vx_get_form_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_vx_init_employee = new vscode.CompletionItem('vx_init_employee', vscode.CompletionItemKind.Function);
                    l_vx_init_employee.insertText = new vscode.SnippetString(' vx_init_employee(${1:Emp id}, ${2:Pay Date}, ${3:Pay Period}, ${4:Pay Period Set}, ${5:Rgeo Code}, ${6:Rgeo Code Set}, ${7:Current Period}), ${8:Current Period Set}, ${9:Futa Rate}, ${10:Futa Rate Set}, ${11:SUI rate}, ${12:SUI Rate Set}, ${13:SDI Rate}, ${14:SDI Rate Set})');
                    l_vx_init_employee.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_vx_set_deduct_amount = new vscode.CompletionItem('vx_set_deduct_amount', vscode.CompletionItemKind.Function);
                    l_vx_set_deduct_amount.insertText = new vscode.SnippetString(' vx_set_deduct_amount(${1:Tax ID}, ${2:Tax Type}, ${3:Deduction Amount ID}, ${4:Amount}, ${5:Amount Set}, ${6:Cash Opt}, ${7:Cash Opt Set}), ${8:Amount Ytd}, ${9:Amount Ytd Set})');
                    l_vx_set_deduct_amount.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_vx_set_form_value = new vscode.CompletionItem('vx_set_form_value', vscode.CompletionItemKind.Function);
                    l_vx_set_form_value.insertText = new vscode.SnippetString(' vx_set_form_value(${1:Tax ID}, ${2:Tax Type}, ${3:Parameter Name}, ${4:Value}, ${5:Value Set})');
                    l_vx_set_form_value.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_vx_set_gross_amount = new vscode.CompletionItem('vx_set_gross_amount', vscode.CompletionItemKind.Function);
                    l_vx_set_gross_amount.insertText = new vscode.SnippetString(' vx_set_gross_amount(${1:Tax ID}, ${2:Tax Type}, ${3:Gross Amount ID}, ${4:Amount}, ${5:Amount Set})');
                    l_vx_set_gross_amount.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_vx_set_tax_amount = new vscode.CompletionItem('vx_set_tax_amount', vscode.CompletionItemKind.Function);
                    l_vx_set_tax_amount.insertText = new vscode.SnippetString(' vx_set_tax_amount(${1:Tax ID}, ${2:Tax Type}, ${3:Tax Amount ID}, ${4:Amount}, ${5:Amount Set})');
                    l_vx_set_tax_amount.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_vx_transfer = new vscode.CompletionItem('vx_transfer', vscode.CompletionItemKind.Function);
                    l_vx_transfer.insertText = new vscode.SnippetString(' vx_transfer()');
                    l_vx_transfer.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    const l_vx_translate = new vscode.CompletionItem('vx_translate', vscode.CompletionItemKind.Function);
                    l_vx_translate.insertText = new vscode.SnippetString(' vx_translate(${1:Type}, ${2:From Value}, ${3:Found}, ${4:Context1[...]}, ${5:Context2[...]}, ${6:Context3[...]}, ${7:Context4[...]}), ${8:Context5[...]}, ${9:Context6[...]})');
                    l_vx_translate.documentation = new vscode.MarkdownString('Oracle Inbuilt Function | Return Data Type : Text');

                    return [getContext, abs, addDays, addlog, addMonths, addRlog, addYears, archiveClear, l_archive_clear_record, l_archive_flush, l_archive_init, l_archive_message, l_archive_value, l_ben_chk_abs_type, l_ben_fn_aca_reporting, l_ben_fn_effective_date, l_ben_fn_get_char_value, l_calculate_hours_worked, l_calculate_payroll_periods, l_calc_dir_exists, l_calc_dir_get_override_level, l_calc_dir_text_value, l_calc_dir_value, l_calc_dir_value_detail, l_ca_formula_logging, l_chr, l_clear_globals, l_convert, l_date_to_text, l_days_between, l_debug, l_define_range, l_define_range_item, l_element_rate_converter, l_ess_log_write, l_floor, l_get_absence, l_get_absence_counts, l_get_absence_days_per_type, l_get_abs_min_max_dates, l_get_accrual_balance, l_get_accrual_band, l_get_asg_inactive_days, l_get_asg_status, l_get_assignment_salary, l_get_assignment_status, l_get_bal_comp_val, l_get_bal_hdr_val, l_get_calculated_hours, l_get_carry_over, l_get_context_value, l_get_context_value_date, l_get_context_value_number, l_get_date, l_get_date_day_of_week, l_get_duration, l_get_earliest_asgchange_date, l_get_element_entry, l_get_end_date, l_get_enrt_dtls, l_get_entitlements, l_get_ent_name, l_get_event_date, l_get_expenditure_type_name, l_get_flow_param_value, l_get_formated_date, l_get_formated_day_of_week, l_get_formula_name, l_get_fvalue_date, l_get_fvalue_number, l_get_fvalue_text, l_get_geography_identifier, l_get_geography_name, l_get_geo_std_name_by_user_code, l_get_grade_name, l_get_hdr_text, l_get_home_city, l_get_home_country, l_get_is_date_same_as_dow, l_get_job_name, l_get_legentity_name, l_get_locaton_name, l_get_lookup_meaning, l_get_measure_from_time, l_get_mesg, l_get_mgr_name, l_get_msg_attribute, l_get_msg_severity, l_get_net_accrual, l_get_number, l_get_org_name, l_get_other_net_contribution, l_get_output_msg, l_get_output_msg1, l_get_output_msg2, l_get_output_msg3, l_get_output_msg4, l_get_parameter_value, l_get_parameter_value_date, l_get_parameter_value_number, l_get_payroll_details, l_get_payroll_dtrange, l_get_payroll_ID, l_get_payroll_period, l_get_pay_availability, l_get_period_dates, l_get_person_transfer_status, l_get_plan_balance, l_get_position_name, l_get_project_number, l_get_rate, l_get_rate_type, l_get_rating_level, l_get_reported_hours, l_get_retro_element, l_get_rule_hdr_text, l_get_rvalue_date, l_get_rvalue_number, l_get_rvalue_text, l_get_start_date, l_get_table_value, l_get_task_number, l_get_termination_date, l_get_text, l_get_value_by_criteria, l_get_value_set, l_get_working_days, l_get_wrk_date, l_get_wrk_num, l_get_wrk_text, l_greatest, l_hrc_create_bo_extract, l_hr_get_table_value, l_hr_trace, l_initcap, l_init_util, l_instr, l_instrb, l_isnull, l_is_date_null, l_is_number_null, l_is_text_null, l_iterative_get_binary_guess, l_iterative_get_high_value, l_iterative_get_interp_guess, l_iterative_get_low_value, l_iterative_get_target_value, l_iterative_initialise, l_iterative_is_amount_set, l_last_day, l_least, l_length, l_lengthb, l_lower, l_lpad, l_ltrim, l_mod, l_months_between, l_new_time, l_next_day, l_num_to_char, l_pay_edn_publish_event, l_pay_get_rate_type, l_pay_internal_log_write, l_pay_log_error, l_pay_log_warning, l_power, l_raise_error, l_rand, l_rand_seed, l_rate_converter, l_rate_engine, l_rate_engine_init, l_rate_engine_put_value, l_remove_globals, l_replace, l_reset_accruals, l_round, l_round_up, l_rpad, l_rtrim, l_set_accrual_balance, l_set_date, l_set_number, l_set_text, l_set_wrk_date, l_set_wrk_num, l_set_wrk_text, l_std_annualized_rate_converter, l_substr, l_substrb, l_taxability_rule_exists, l_time_hhmm_to_dec, l_to_char, l_to_date, l_to_number, l_to_text, l_translate, l_trim, l_trunc, l_unit_converter, l_update_context_array, l_update_parameter_array, l_upper, l_us_adjust_tax_balances, l_us_formula_logging, l_us_pr_ext_tax_code_count, l_us_state_abbreviation, l_value_criteria_init, l_value_criteria_put_value, l_vx_calculate, l_vx_get_form_value, l_vx_init_employee, l_vx_set_deduct_amount, l_vx_set_form_value, l_vx_set_gross_amount, l_vx_set_tax_amount, l_vx_transfer, l_vx_translate];
                }
            },
            '='
        )
    );
};

export function devexDotFunctions(context: vscode.ExtensionContext) {
    context.subscriptions.push(
        vscode.languages.registerCompletionItemProvider(
            DEFAULT_DEVEX_LANGUAGE,
            {
                provideCompletionItems(document: vscode.TextDocument, position: vscode.Position) {

                    let funcExists = new vscode.CompletionItem('exists', vscode.CompletionItemKind.Method);
                    funcExists.insertText = 'exists(index)';

                    let funcCount = new vscode.CompletionItem('count', vscode.CompletionItemKind.Method);
                    funcCount.insertText = 'count';

                    let funcFirst = new vscode.CompletionItem('first', vscode.CompletionItemKind.Method);
                    funcFirst.insertText = 'first(-99)';

                    let funcPrevious = new vscode.CompletionItem('previous', vscode.CompletionItemKind.Method);
                    funcPrevious.insertText = 'previous(index)';

                    let funcNext = new vscode.CompletionItem('next', vscode.CompletionItemKind.Method);
                    funcNext.insertText = 'next(index)';

                    let funcLast = new vscode.CompletionItem('last', vscode.CompletionItemKind.Method);
                    funcLast.insertText = 'last(-99)';

                    return [
                        funcExists,
                        funcCount,
                        funcFirst,
                        funcPrevious,
                        funcNext,
                        funcLast
                    ];
                }
            },
            '.'
        )
    );
};