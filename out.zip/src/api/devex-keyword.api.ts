
'use strict';
import * as vscode from 'vscode';
import * as constants from '../constants';
export function devexKeywords(context : vscode.ExtensionContext, data : String)
{
    let words = data.split(" ");
    words = words.filter((el, i, a) => i === a.indexOf(el));
    let wordCount = words.length; 
    for (let i = 0; i < wordCount; i++)
    {							
        context.subscriptions.push(vscode.languages.registerCompletionItemProvider(
            constants.DEFAULT_DEVEX_LANGUAGE,
            {
                provideCompletionItems(document: vscode.TextDocument, position: vscode.Position) {
                    let customData = new vscode.CompletionItem(words[i], vscode.CompletionItemKind.Keyword);
                    customData.insertText =  words[i]+ ' ';
                    return [customData];
                }
            }
        ));
    }
}