import * as constants from '../constants';
/**
 * Create asnyc request to ChatGpt api to generate a new images.
 * @param prompt 
 * @param apiKey 
 * @param n 
 * @param size 
 * @returns 
 */
export async function devexImagine(prompt: string | undefined, apiKey: string, n: number = 1, size: string = "1024x1024") {
    try {
        const apiUrl = constants.DEFAULT_IMAGINE_URL;
        const apiKey = constants.DEFAULT_CHAT_KEY;

        // 👇️ const response: Response
        const response = await fetch(apiUrl, {
            method: 'POST',
            body: JSON.stringify({
                prompt: prompt,
                n: Number(n),
                size: size
            }),
            headers: {
                "Content-Type": 'application/json',
                authorization: 'Bearer ' + apiKey,
            },
        });

        if (!response.ok) {
            throw new Error(`Error! status: ${response.status}`);
        }

        const result: any = (await response.json());

        return result.data;
    } catch (error) {
        if (error instanceof Error) {
            console.log('error message: ', error.message);
            return error.message;
        } else {
            console.log('unexpected error: ', error);
            return 'An unexpected error occurred';
        }
    }
}