import { fetch } from 'undici';
import * as constants from '../constants';
/**
 * Create asnyc request to ChatGpt api gets a response.
 * @param question is that want to ask to ChatGpt.
 * @param apikey of ChatGpt.
 * @returns 
 */
export async function devexChat(query: string | undefined, apiKey: string) {
    try {
        const apiUrl = constants.DEFAULT_CHAT_URL;
        const apiKey = constants.DEFAULT_CHAT_KEY;
        const apiModel = constants.DEFAULT_CHAT_MODEL;

        // 👇️ const response: Response
        const response = await fetch(apiUrl, {
            method: 'POST',
            body: JSON.stringify({
                model: apiModel,
                messages: [{ role: "user", content: query }],
                temperature: 0.7
            }),
            headers: {
                "Content-Type": 'application/json',
                authorization: 'Bearer ' + apiKey,
            },
        });

        if (!response.ok) {
            throw new Error(`Error! status: ${response.status}`);
        }

        const result: any = (await response.json());

        return result.choices[0].message.content;
    } catch (error) {
        if (error instanceof Error) {
            console.log('error message: ', error.message);
            return error.message;
        } else {
            console.log('unexpected error: ', error);
            return 'An unexpected error occurred';
        }
    }
}