
'use strict';
import * as vscode from 'vscode';
import * as constants from '../constants';
import  ffContexts  from '../ff-token.json';

export function devexContexts(context: vscode.ExtensionContext, actionNumber : number) {
    const eligibleContexts = vscode.languages.registerCompletionItemProvider(
		constants.DEFAULT_DEVEX_LANGUAGE,
		{
			provideCompletionItems(document: vscode.TextDocument, position: vscode.Position) {
                return fetchContextsFromJson();
			}
		}
	);
    

   

}

function fetchContextsFromJson()
{
    const documentFileName = vscode.window.activeTextEditor?.document.fileName;
    let data : String = '';
    let ffType : string = 'unknown';
    if (documentFileName !== undefined)
    {
        let fileNameSplits = documentFileName.split('.');
        if (fileNameSplits.length > 2)
        {
            ffType = fileNameSplits[fileNameSplits.length - 2];
        }

        switch(ffType)
        {
            case 'absence' : data = ffContexts.absence.contexts; break;
            case 'accrual' : data = ffContexts.accrual.contexts; break;
            default : data = ffContexts.unknown.contexts; break;
        }
    }
    console.log('Devex context for ' + ffType + ' = ' + data);
    let conextsWordList = data.split("|");
    conextsWordList = conextsWordList.filter((el, i, a) => i === a.indexOf(el));
    let contextsCount = conextsWordList.length;

    let eligibleContextList: vscode.CompletionItem[]  = [];
    for (let index = 0; index < contextsCount; index++) {
        const contextItem = new vscode.CompletionItem(conextsWordList[index], vscode.CompletionItemKind.Interface);
        contextItem.insertText = conextsWordList[index];
        eligibleContextList[index] = contextItem;
    }

    return eligibleContextList;
}

