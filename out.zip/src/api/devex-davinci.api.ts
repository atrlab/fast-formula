import { fetch } from 'undici';
import * as constants from '../constants';
export async function devexDavinci(prompt: string) {
    try {
        const apiUrl = constants.DEFAULT_CHAT_URL;
        const apiKey = constants.DEFAULT_CHAT_KEY;
        const apiModel = constants.DAVINCI_CHAT_MODEL;

        // 👇️ const response: Response
        const response = await fetch(apiUrl, {
            method: 'POST',
            body: JSON.stringify({
                model:apiModel,
                prompt: prompt,
                max_tokens: 2048,
                temperature: 0.0,
                top_p: 0.1
            }),
            headers: {
                "Content-Type": 'application/json',
                authorization: 'Bearer ' + apiKey,
            },
        });

        if (!response.ok) {
            throw new Error(`Error! status: ${response.status}`);
        }

        const result: any = (await response.json());

        return result.choices[0].text;
    } catch (error) {
        if (error instanceof Error) {
            console.log('error message: ', error.message);
        } else {
            console.log('unexpected error: ', error);
        }
        throw error;
    }
}
