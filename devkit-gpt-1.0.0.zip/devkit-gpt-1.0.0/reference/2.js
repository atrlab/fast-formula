const createInstanceWithRetry = (instance, lines=[]) => {
    return {
        ...instance,
        async post(url, data, options) {
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                try {
                    const response = await instance.post(`${line.base}${url}`, data, {
                        ...options,
                        headers: {
                            ...options.headers,
                            'Authorization': `Bearer ${line.key}`
                        },
                    });
                    return response;
                } catch (error) {
                    if (i === lines.length - 1) throw error;
                }
            }
        },
    };
};