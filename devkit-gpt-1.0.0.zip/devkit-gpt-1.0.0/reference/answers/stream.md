data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"role":"assistant"},"index":0,"finish_reason":null}]}
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":"The"},"index":0,"finish_reason":null}]}
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":" result"},"index":0,"finish_reason":null}]}
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":" of"},"index":0,"finish_reason":null}]}
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":" "},"index":0,"finish_reason":null}]}
------------------
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":"2"},"index":0,"finish_reason":null}]}
------------------
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":"+"},"index":0,"finish_reason":null}]}
------------------
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":"2"},"index":0,"finish_reason":null}]}
------------------
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{"content":"."},"index":0,"finish_reason":null}]}
------------------
data: {"id":"chatcmpl-7QZOtYAhtz2jc8ms2xXvUnz5lfzf4","object":"chat.completion.chunk","created":1686566963,"model":"gpt-3.5-turbo-0301","choices":[{"delta":{},"index":0,"finish_reason":"stop"}]}
data: [DONE]