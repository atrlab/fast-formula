## ChatGPT (English)
- Free GPT-4 AI Assistant, no Key and no magic required
- This is a VSCode extension that supports OpenAI's GPT-4, GPT-3.5 models.
- It allows configuration of API key, model, temperature, and maxTokens in the plugin settings.
- Supports multiple languages including Chinese, English, Korean, Japanese, and others.
- It comes with a built-in free API key, with no need for registration, no login, no magic,and no payment required for use.

## Commands:
- `ChatGPT: Update API key` (It will provide you with a prompt to enter a new API key and will validate the remaining balance and validity of the API key you currently input.)
- `ChatGPT: Validate API key` (Validate the remaining balance and validity of the current API key)
- `ChatGPT: Set language` (will set the language for you)
- `ChatGPT: Ask a question` (will provide you with a prompt to ask a question)
- `ChatGPT: Add a test for this code for me` (will generate test code based on file/text selection)
- `ChatGPT: Why is there a bug in this code?` (will analyze your code and highlight any logical/syntax errors)
- `ChatGPT: Custom question` (You can customize your own question)
- `ChatGPT: Help me explain the code?` (will explain the code for you)
- `ChatGPT: Refactor this code and tell me what did you change?` (will refactor the code for you)

> All content can be accessed from the context menu by right-clicking anywhere in the editor.

## How to Use
### Get API keys
- To obtain an API key from OpenAI, you need to register an account on the OpenAI website first. Once registered, you can log in to your account and find the API keys section in the settings page at https://beta.openai.com/account/api-keys. You can generate new API keys here or view existing ones.
- `Ctrl+Shift+P` is a common shortcut in Visual Studio Code used to open the command palette. The command palette is a pop-up window that is used to access various commands in Visual Studio Code. If you want to update the API key, you can enter the command ChatGPT: Update API key and enter the new API key.
