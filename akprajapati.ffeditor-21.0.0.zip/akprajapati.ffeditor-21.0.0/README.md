# Synopsis

An Extension to develop the Fast Formula in easy way. <br>
This Extension contains **Lexar**, **Static DBIs**, **Context**, **Predefined Functions** and **Token Helper**.
<br>The important features of this release are  Lexical Analysis, IntelliSense for Keywords, Context Functions, Data Conversion Functions, Text Functions, Date Functions, Numeric Functions and Miscellaneous Functions. The user can fetch Meta line for the formula and sample formula as well.
    <br>It Includes
    <br>- 23000+ DBIs
    <br>- 120+ Predefined Contexts
    <br>- 350+ Inbuilt Basic Functions
    <br>- All available Keywords
    <br>- IOC for Fast Formula Type (Beta)
    <br>- Initializers
    <br>- Sample Formula (Beta)

## Motivation

Do you want write **Fast Formula**? <br>
Don't worry this extension will help you to write Fast Formula.

# Token Helper
## Lexing Scheme
    - Comments   = Dark Green
    - Contexts   = Navy Blue Bold
    - Data Types = Black Bold
    - DBIs       = Pine Green
    - Functions  = Red
    - Keywords   = Blue
    - Literals   = Maroon
    - Operators  = Black
    - Userdefined= Black
    

## Keywords
    -alias
    -and
    -are
    -as
    -default
    -default_data_value
    -defaulted
    -else
    -exit
    -for
    -if
    -inputs
    -is
    -like
    -loop
    -not
    -or
    -return
    -then
    -was
    -while


## Data Type and Initializers
    -date
    -DATE_NUMBER
    -DATE_TEXT
    -EMPTY_DATE_NUMBER
    -EMPTY_DATE_TEXT
    -EMPTY_NUMBER_NUMBER
    -EMPTY_NUMBER_TEXT
    -EMPTY_TEXT_NUMBER
    -EMPTY_TEXT_TEXT
    -number
    -NUMBER_NUMBER
    -NUMBER_TEXT
    -text
    -TEXT_NUMBER
    -TEXT_TEXT


## Functions
    -abs
    -add_days
    -add_months
    -add_rlog
    -add_years
    -call_formula
    -change_contexts
    -context_is_set
    -count
    -date_to_text
    -days_between
    -delete
    -ess_log_write
    -execute
    -exists
    -first
    -floor
    -get_context
    -get_fnd_mesg
    -get_mesg
    -get_output
    -get_table_value
    -get_value_set
    -get_working_days
    -greatest
    -hr_trace
    -initcap
    -instr
    -last
    -last_day
    -least
    -length
    -lower
    -lpad
    -ltrim
    -mod
    -months_between
    -new_time
    -next
    -next_day
    -num_to_char
    -power
    -prior
    -replace
    -round
    -roundup
    -rpad
    -rtrim
    -set_input
    -substr
    -to_char
    -to_date
    -to_number
    -translate
    -trim
    -trunc
    -upper
    -wsa_delete
    -wsa_exists
    -wsa_get
    -wsa_set
    
## Predefined Context
    -ABSENCE_CATEGORY_ID
    -ABSENCE_ENTRY_ID
    -ABSENCE_REASON_ID
    -ABSENCE_TYPE_ID
    -ACCRUAL_PLAN_ID
    -ACTION_CODE
    -ACTION_ID
    -ACTION_OCCURRENCE_ID
    -ACTION_REASON_CODE
    -ACTION_REASON_ID
    -ACTY_BASE_RT_ID
    -ADDRESS_ID
    -ADDRESS_TYPE
    -AREA1
    -AREA2
    -AREA3
    -AREA4
    -BAL_ADJ_LINE_ID
    -BENEFIT_RELATION_ID
    -BNFTS_BAL_ID
    -BUSINESS_GROUP_ID
    -CALC_BREAKDOWN_ID
    -COMPENSATION_RECORD_TYPE
    -CRT_ORDR_TYP_CD
    -DATE_EARNED
    -DEDUCTION_CARD_ID
    -DIR_CARD_COMP_ID
    -DYN_PRD_END_DATE
    -DYN_PRD_START_DATE
    -EFFECTIVE_DATE
    -ELEMENT_ENTRY_ID
    -ELEMENT_TYPE_ID
    -ELIG_PER_ELCTBL_CHC_ID
    -ELIG_PER_ID-END_DATE
    -ENRT_BNFT_ID-ENRT_CTFN_TYP_CD
    -ENTERPRISE_ID-ENTRY_USAGE_ID
    -EXCL_ABSENCE_CATEGORY_ID
    -EXCL_ABSENCE_REASON_ID
    -EXCL_ABSENCE_TYPE_ID
    -GRADE_ID
    -GRADE_RATE_ID
    -HR_ASSIGNMENT_ID
    -HR_RELATIONSHIP_ID
    -HR_TERM_ID
    -HWM_CTX_SEARCH_END_DATE
    -HWM_CTX_SEARCH_START_DATE
    -HWM_RESOURCE_ID
    -HWM_SUBRESOURCE_ID
    -INSURANCE_TYPE-JOB_ID
    -LC_DATE_FROM
    -LC_DATE_TO
    -LEGAL_EMPLOYER_ID
    -LEGAL_ENTITY_ID
    -LEGISLATIVE_DATA_GROUP_ID
    -LER_ID
    -LOCATION_ID
    -LOOKUP_CODE
    -LOOKUP_TYPE
    -MARITAL_STATUS
    -METHOD_NAME
    -OBJECT_GROUP_ID
    -OPT_ID
    -ORG_CLASSIFICATION_CODE
    -ORGANIZATION_ID
    -PAYROLL_ACTION_ID
    -PAYROLL_ASSIGNMENT_ID
    -PAYROLL_ID
    -PAYROLL_REL_ACTION_ID
    -PAYROLL_RELATIONSHIP_ID
    -PAYROLL_STAT_UNIT_ID
    -PAYROLL_TERM_ID
    -PER_IN_LER_ID
    -PERSON_ID
    -PGM_ID-PL_ID
    -PL_TYP_ID
    -POSITION_ID
    -REFERENCE_CODE
    -REFERENCE_NUMBER
    -REGN_ID
    -REPORTING_REFERENCE_CODE
    -REPORTING_TIME_PERIOD_ID
    -RPTG_GRP_ID
    -START_DATE
    -STATUTORY_REPORT_CODE
    -STATUTORY_REPORT_TYPE
    -TALENT_PROFILE_CONTENT_TYPE
    -TAX_UNIT_ID
    -THIRD_PARTY_PAYEE_ID
    -WORK_NUMBER
    -XLE_LEG_CATEGORY_CODE
    -XLE_LEGAL_AUTHORITY_ID

   
### **Keywords**
    In programming, a keyword is a word that is reserved by a program because the word has a special meaning. 
    Keywords can be commands or parameters. Every programming language has a set of keywords that cannot be used as variable names. 
    Keywords are sometimes called reserved names.
    Examples for keywords are as follows:
    - inputs
    - alias
    - default etc.,

### **Context**
    Generally formulas run within an application specific execution context which in turn determines the available context variables. 
    Context values act as SQL bind values the formula fetches the database item values from the database.
    In addition to that formulas can also pass context values into formula function calls. 
    Examples for Context are as follows:
    - EFFECTIVE_DATE
    - PERSON_ID
    - PAYROLL_ID etc.,

### **Data Conversion Function**
    Data conversion functions such as the CONVERT function that converts a character string from one character set to another.
    Examples are as follows: 
    - TO_DATE (expr [, format]) : Converts the character string expr in the specified format to a date. If no format is specified then expr must be in canonical format.
    - NUM_TO_CHAR(n, format) : Converts the number n to a character string in the specified format. This function is equivalent to the SQL TO_CHAR function.

### **Text Function**
    The Text formula functions manipulate text data. 
    Examples are as follows:
    - CHR(n): Returns the character having the binary equivalent to a number operand n in the ASCII character set.
    - LENGTH(expr): Returns the number of characters in the text string operand expr.

### **Numerical Function**
    The numeric formula functions manipulate numeric data. 
    Examples are as follows:
    - MOD(m, n): Returns the remainder from dividing m by n.
    - POWER(m, n): Returns m raised to the nth power.

### **Date Function**
    The date formula functions manipulate date data.
    Example is as follows:
    - ADD_MONTHS(date, n): Adds n whole months to date.

### **Miscellaneous Function**
    The formula function manupulate messaging data. The function Returns an expanded version of the application message specified using appname, 
    msgname and up to five pairs of message tokens and their corresponding values. 
    Example: 
    - HR_TRACE(expr): Outputs a trace message. It is more efficient to us a application-specific logging function than HR_TRACE.
# Developer & Contributor
## Developer
    A.K. Prajapati, +91-9565666734, ajeetkumarp@kpmg.com

## Contributor


# License & Restriction
## Privacy & Policy
Permission to use, copy, modify, and distribute this Plugnin and its documentation for any purpose and without fee is hereby <br>granted for **KPMG**, provided that the above copyright notice appear in all copies and that both that copyright<br> notice and this permission notice appear in supporting documentation.

## Restriction
**KPMG Internal Use Only**


## License Details
**License Type - Enterprise Volumn License, Key - P76T3-4VXXJ-8FY44-C4R2C-GPFBJ, Valid Till 2021/12/31**

## Self Terminator Note
This package is a distro and capable to self terminate after expiration. Any changes or applying crack or piration of this package is subject to security risk. Please do at your own risk. 